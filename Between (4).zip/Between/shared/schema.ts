import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, boolean, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const profiles = pgTable("profiles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  fullName: text("full_name"),
  phone: text("phone"),
  location: text("location"),
  bio: text("bio"),
  health: text("health"),
  disability: text("disability"),
  profileImage: text("profile_image"),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertProfileSchema = createInsertSchema(profiles).omit({
  id: true,
  updatedAt: true,
});

export type InsertProfile = z.infer<typeof insertProfileSchema>;
export type Profile = typeof profiles.$inferSelect;

export const experiences = pgTable("experiences", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  profileId: varchar("profile_id").notNull().references(() => profiles.id, { onDelete: 'cascade' }),
  type: text("type").notNull(),
  title: text("title").notNull(),
  company: text("company").notNull(),
  startDate: text("start_date").notNull(),
  endDate: text("end_date"),
  current: boolean("current").notNull().default(false),
  description: text("description"),
});

export const insertExperienceSchema = createInsertSchema(experiences).omit({
  id: true,
});

export type InsertExperience = z.infer<typeof insertExperienceSchema>;
export type Experience = typeof experiences.$inferSelect;

export const discussions = pgTable("discussions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  author: text("author").notNull(),
  category: text("category").notNull(),
  replies: integer("replies").notNull().default(0),
  views: integer("views").notNull().default(0),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const insertDiscussionSchema = createInsertSchema(discussions).omit({
  id: true,
  replies: true,
  views: true,
  timestamp: true,
});

export type InsertDiscussion = z.infer<typeof insertDiscussionSchema>;
export type Discussion = typeof discussions.$inferSelect;

export const comments = pgTable("comments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  discussionId: varchar("discussion_id"),
  author: text("author").notNull(),
  content: text("content").notNull(),
  likes: integer("likes").notNull().default(0),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const insertCommentSchema = createInsertSchema(comments).omit({
  id: true,
  likes: true,
  timestamp: true,
});

export type InsertComment = z.infer<typeof insertCommentSchema>;
export type Comment = typeof comments.$inferSelect;

// Email schemas for contact and support forms
export const contactFormSchema = z.object({
  name: z.string().min(1, "El nombre es requerido"),
  email: z.string().email("Email inválido"),
  phone: z.string().optional(),
  message: z.string().min(10, "El mensaje debe tener al menos 10 caracteres"),
});

export const supportFormSchema = z.object({
  name: z.string().min(1, "El nombre es requerido"),
  email: z.string().email("Email inválido"),
  subject: z.string().min(1, "El asunto es requerido"),
  message: z.string().min(10, "El mensaje debe tener al menos 10 caracteres"),
});

export type ContactForm = z.infer<typeof contactFormSchema>;
export type SupportForm = z.infer<typeof supportFormSchema>;

// Job application schema
export const jobApplicationSchema = z.object({
  jobId: z.string().min(1, "Job ID es requerido"),
  jobTitle: z.string().min(1, "El título del trabajo es requerido"),
  company: z.string().min(1, "La empresa es requerida"),
  applicantName: z.string().min(1, "El nombre es requerido").optional(),
  applicantEmail: z.string().email("Email inválido").optional(),
  cvFileName: z.string().optional(),
  additionalDocsFileName: z.string().optional(),
  disabilityCertFileName: z.string().optional(),
});

export type JobApplication = z.infer<typeof jobApplicationSchema>;

export const jobs = pgTable("jobs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  company: text("company").notNull(),
  location: text("location").notNull(),
  type: text("type").notNull(),
  salary: text("salary"),
  description: text("description").notNull(),
  requirements: text("requirements").array(),
  responsibilities: text("responsibilities").array(),
  benefits: text("benefits").array(),
  lat: decimal("lat", { precision: 10, scale: 7 }),
  lng: decimal("lng", { precision: 10, scale: 7 }),
  postedDate: timestamp("posted_date").notNull().defaultNow(),
  featured: boolean("featured").notNull().default(false),
});

export const insertJobSchema = createInsertSchema(jobs).omit({
  id: true,
  postedDate: true,
});

export type InsertJob = z.infer<typeof insertJobSchema>;
export type Job = typeof jobs.$inferSelect;

export const jobApplicationsDb = pgTable("job_applications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  jobId: varchar("job_id").notNull().references(() => jobs.id, { onDelete: 'cascade' }),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  jobTitle: text("job_title").notNull(),
  company: text("company").notNull(),
  applicantName: text("applicant_name"),
  applicantEmail: text("applicant_email"),
  cvFileName: text("cv_file_name"),
  additionalDocsFileName: text("additional_docs_file_name"),
  disabilityCertFileName: text("disability_cert_file_name"),
  status: text("status").notNull().default('pending'),
  appliedAt: timestamp("applied_at").notNull().defaultNow(),
});

export const insertJobApplicationDbSchema = createInsertSchema(jobApplicationsDb).omit({
  id: true,
  status: true,
  appliedAt: true,
});

export type InsertJobApplicationDb = z.infer<typeof insertJobApplicationDbSchema>;
export type JobApplicationDb = typeof jobApplicationsDb.$inferSelect;

export const courses = pgTable("courses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  category: text("category").notNull(),
  duration: text("duration").notNull(),
  level: text("level").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertCourseSchema = createInsertSchema(courses).omit({
  id: true,
  createdAt: true,
});

export type InsertCourse = z.infer<typeof insertCourseSchema>;
export type Course = typeof courses.$inferSelect;

export const lessons = pgTable("lessons", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  courseId: varchar("course_id").notNull().references(() => courses.id, { onDelete: 'cascade' }),
  title: text("title").notNull(),
  duration: text("duration").notNull(),
  order: integer("order").notNull(),
});

export const insertLessonSchema = createInsertSchema(lessons).omit({
  id: true,
});

export type InsertLesson = z.infer<typeof insertLessonSchema>;
export type Lesson = typeof lessons.$inferSelect;

export const courseProgress = pgTable("course_progress", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  courseId: varchar("course_id").notNull().references(() => courses.id, { onDelete: 'cascade' }),
  lessonId: varchar("lesson_id").notNull().references(() => lessons.id, { onDelete: 'cascade' }),
  completed: boolean("completed").notNull().default(true),
  completedAt: timestamp("completed_at").notNull().defaultNow(),
});

export const insertCourseProgressSchema = createInsertSchema(courseProgress).omit({
  id: true,
  completed: true,
  completedAt: true,
});

export type InsertCourseProgress = z.infer<typeof insertCourseProgressSchema>;
export type CourseProgress = typeof courseProgress.$inferSelect;

export const usersRelations = relations(users, ({ one, many }) => ({
  profile: one(profiles, {
    fields: [users.id],
    references: [profiles.userId],
  }),
  jobApplications: many(jobApplicationsDb),
  courseProgress: many(courseProgress),
}));

export const profilesRelations = relations(profiles, ({ one, many }) => ({
  user: one(users, {
    fields: [profiles.userId],
    references: [users.id],
  }),
  experiences: many(experiences),
}));

export const experiencesRelations = relations(experiences, ({ one }) => ({
  profile: one(profiles, {
    fields: [experiences.profileId],
    references: [profiles.id],
  }),
}));

export const jobsRelations = relations(jobs, ({ many }) => ({
  applications: many(jobApplicationsDb),
}));

export const jobApplicationsRelations = relations(jobApplicationsDb, ({ one }) => ({
  job: one(jobs, {
    fields: [jobApplicationsDb.jobId],
    references: [jobs.id],
  }),
  user: one(users, {
    fields: [jobApplicationsDb.userId],
    references: [users.id],
  }),
}));

export const coursesRelations = relations(courses, ({ many }) => ({
  lessons: many(lessons),
  progress: many(courseProgress),
}));

export const lessonsRelations = relations(lessons, ({ one, many }) => ({
  course: one(courses, {
    fields: [lessons.courseId],
    references: [courses.id],
  }),
  progress: many(courseProgress),
}));

export const courseProgressRelations = relations(courseProgress, ({ one }) => ({
  user: one(users, {
    fields: [courseProgress.userId],
    references: [users.id],
  }),
  course: one(courses, {
    fields: [courseProgress.courseId],
    references: [courses.id],
  }),
  lesson: one(lessons, {
    fields: [courseProgress.lessonId],
    references: [lessons.id],
  }),
}));
