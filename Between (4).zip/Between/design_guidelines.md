# Between - Design Guidelines

## Design Approach
**System-Based with Cultural Context**: Material Design foundation adapted for Peruvian employment market, prioritizing accessibility, clarity, and trust-building. The platform balances utility (job search) with supportive educational content.

**Key References**: LinkedIn (professional credibility), Indeed (job search functionality), Coursera (educational resources), with accessibility standards for disability inclusion.

## Core Design Principles
1. **Trustworthy & Professional**: Users are making career decisions - design must inspire confidence
2. **Inclusive by Default**: Accessibility isn't optional - it's core to the mission
3. **Information Clarity**: Dense data presented digestibly
4. **Empowering Tone**: Educational content feels supportive, not condescending

## Typography
- **Primary Font**: Inter (Google Fonts) - clean, readable, professional
- **Secondary Font**: Poppins (Google Fonts) - friendly warmth for educational content
- **Hierarchy**:
  - Page Titles: text-4xl md:text-5xl, font-bold
  - Section Headers: text-2xl md:text-3xl, font-semibold
  - Card Titles: text-lg font-semibold
  - Body Text: text-base, leading-relaxed
  - Small Text: text-sm
  - Labels: text-xs uppercase tracking-wide

## Layout System
**Spacing Units**: Use Tailwind units of 2, 4, 6, 8, 12, 16, 20, 24 for consistency
- Component padding: p-4 to p-6
- Section spacing: py-12 md:py-16 lg:py-20
- Card gaps: gap-4 to gap-6
- Container max-width: max-w-7xl for main content, max-w-4xl for forms/profiles

**Grid System**:
- Job listings: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Educational cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Profile sections: Single column with max-w-4xl for readability

## Component Library

### Navigation
- **Main Header**: Sticky navigation with logo left, primary actions right (Search Jobs, Login/Profile)
- **Mega Menu**: Dropdown for "Resources" showing Courses, Workshops, Guides in organized columns
- Includes accessibility link prominently placed

### Job Map Interface
- **Interactive Map**: Full-width map section (h-96 md:h-[500px]) with location markers
- **Map Controls**: Filter sidebar (fixed on desktop, drawer on mobile) with search, location, category, salary range
- **Marker Popups**: Compact job preview with title, company, location, salary - "View Details" button

### Job Cards
- **Structure**: Image/company logo header, title, company name, location icon + city, salary range, key requirements (3-4 bullets), "Apply Now" CTA
- **Density**: Comfortable spacing with p-6, clear visual separation between cards
- **Hover State**: Subtle elevation increase (shadow-lg)

### Job Detail Page
- **Hero Section**: Company header with logo, cover image if available, job title (text-3xl), location, posted date
- **Two-Column Layout**: 
  - Main (2/3): Description, requirements, responsibilities, benefits
  - Sidebar (1/3): Sticky application form, company info, similar jobs
- **Application Form**: File upload with drag-n-drop, clear labeling for CV, additional docs, disability certificate (optional but visible)

### User Profile
- **Dashboard Layout**: Left sidebar navigation (Profile, Applications, Saved Jobs, Documents, Settings)
- **Content Area**: Form-based sections with clear headings, grouped fields
- **Document Management**: Upload grid showing thumbnails, file names, upload dates with delete option
- **Progress Indicators**: Completion percentage for profile sections

### Educational Resources
- **Course Cards**: Image header, category tag, title, duration, difficulty level, "Start Learning" CTA
- **Grid Layout**: 3-column on desktop, stacked on mobile
- **Detail Pages**: Single-column content with sidebar showing progress, related courses

### Community Section
- **Discussion Board**: Traditional forum layout with recent posts, categories, search
- **Comment System**: Threaded conversations, user avatars, timestamps
- **Engagement**: Like/helpful buttons, share functionality

### Forms & Inputs
- **Consistent Style**: Outlined inputs with focus states, clear labels above fields
- **Required Fields**: Asterisk indication, helpful error messages
- **File Upload**: Dashed border drag zones with file type/size guidance
- **Accessibility**: High contrast labels, ARIA labels, keyboard navigation support

### Buttons
- **Primary CTA**: Solid buttons for main actions (Apply, Submit, Save)
- **Secondary**: Outlined buttons for alternative actions
- **Sizes**: py-2 px-4 (small), py-3 px-6 (default), py-4 px-8 (large)
- **On Images**: Backdrop blur background (backdrop-blur-sm bg-white/90) for hero CTAs

### Cards & Containers
- **Standard Cards**: Rounded corners (rounded-lg), subtle shadows (shadow-md)
- **Spacing**: Consistent p-6 for content, gap-4 between elements
- **Borders**: Use sparingly for separation

## Images

### Hero Image
- **Landing Page**: Large hero showing diverse Peruvian workers in professional settings (1920x800px min)
- Overlay with semi-transparent gradient for text readability
- Centered headline + subheadline + dual CTAs ("Find Jobs" + "Learn New Skills")

### Supporting Images
- **Job Listings**: Company logos (square, 80x80px)
- **Educational Content**: Course thumbnails (16:9 ratio, min 640x360px)
- **Profile**: User avatars (circular, 120x120px)
- **Community**: Small user avatars (40x40px) for comments
- **About/Trust Signals**: Team photos, partner logos

### Placement Strategy
- Hero: Full-width background with overlay
- Job cards: Small company logo top-left of card
- Course cards: Full-width header image
- Profile: Avatar top of profile section
- Community: Inline avatars with posts

## Accessibility Features
- **Disability Accommodation**: Clearly marked optional field in applications, no stigma
- **Screen Reader**: All images with alt text, semantic HTML, ARIA labels
- **Keyboard Navigation**: Full site navigable without mouse
- **Contrast**: WCAG AA compliant minimum
- **Text Scaling**: Responsive text that doesn't break layout when scaled
- **Focus Indicators**: Clear visible focus states

## Animations
- **Minimal & Purposeful**: Use only for feedback and state changes
- **Transitions**: 150-300ms for hover states, menu toggles
- **Loading States**: Skeleton screens for content loading, spinner for actions
- **Micro-interactions**: Checkbox animations, file upload progress

## Responsive Behavior
- **Mobile-First**: Stack multi-column layouts, drawer navigation, simplified map controls
- **Breakpoints**: sm (640px), md (768px), lg (1024px), xl (1280px)
- **Touch Targets**: Minimum 44x44px for mobile buttons/links
- **Map on Mobile**: Collapsible with list view alternative

This design creates a professional, trustworthy platform that empowers Peruvian job seekers while maintaining accessibility and usability across all features.