import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import CookieBanner from "@/components/CookieBanner";
import TermsDialog from "@/components/TermsDialog";
import Home from "@/pages/Home";
import Jobs from "@/pages/Jobs";
import JobDetail from "@/pages/JobDetail";
import Courses from "@/pages/Courses";
import CourseDetail from "@/pages/CourseDetail";
import Community from "@/pages/Community";
import Profile from "@/pages/Profile";
import PublicProfile from "@/pages/PublicProfile";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import Support from "@/pages/Support";
import Help from "@/pages/Help";
import Contact from "@/pages/Contact";
import Accessibility from "@/pages/Accessibility";
import Privacy from "@/pages/Privacy";
import Terms from "@/pages/Terms";
import CookiesPolicy from "@/pages/Cookies";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/jobs" component={Jobs} />
      <Route path="/jobs/:id" component={JobDetail} />
      <Route path="/courses" component={Courses} />
      <Route path="/courses/:id" component={CourseDetail} />
      <Route path="/community" component={Community} />
      <Route path="/profile" component={Profile} />
      <Route path="/profile/public" component={PublicProfile} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/support" component={Support} />
      <Route path="/help" component={Help} />
      <Route path="/contact" component={Contact} />
      <Route path="/accessibility" component={Accessibility} />
      <Route path="/privacy" component={Privacy} />
      <Route path="/terms" component={Terms} />
      <Route path="/cookies" component={CookiesPolicy} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
        <CookieBanner />
        <TermsDialog />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
