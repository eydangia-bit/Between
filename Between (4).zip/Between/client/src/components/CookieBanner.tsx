import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Cookie } from "lucide-react";
import { useState, useEffect } from "react";

export default function CookieBanner() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const cookiesAccepted = localStorage.getItem("cookiesAccepted");
    const termsAccepted = localStorage.getItem("termsAccepted");
    
    if (cookiesAccepted !== "true" && termsAccepted === "true") {
      setIsVisible(true);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem("cookiesAccepted", "true");
    setIsVisible(false);
  };

  const rejectCookies = () => {
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-[9999] p-4 animate-in slide-in-from-bottom-5 duration-500">
      <Card className="max-w-4xl mx-auto p-6 shadow-2xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="flex-shrink-0">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
              <Cookie className="h-6 w-6 text-primary" />
            </div>
          </div>
          
          <div className="flex-1 space-y-2">
            <h3 className="text-lg font-semibold" data-testid="text-cookie-title">
              Uso de Cookies
            </h3>
            <p className="text-sm text-muted-foreground">
              Utilizamos cookies para mejorar tu experiencia en nuestra plataforma. 
              Las cookies nos ayudan a personalizar el contenido, ofrecer funcionalidades 
              de redes sociales y analizar nuestro tráfico. Al hacer clic en "Aceptar", 
              aceptas el uso de cookies.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
            <Button
              variant="outline"
              onClick={rejectCookies}
              className="w-full sm:w-auto"
              data-testid="button-reject-cookies"
            >
              Rechazar
            </Button>
            <Button
              onClick={acceptCookies}
              className="w-full sm:w-auto"
              data-testid="button-accept-cookies"
            >
              Aceptar
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
