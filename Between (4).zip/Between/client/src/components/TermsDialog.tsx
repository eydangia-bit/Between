import { useState, useEffect } from "react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { ScrollArea } from "@/components/ui/scroll-area";

export default function TermsDialog() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const hasAcceptedTerms = localStorage.getItem("termsAccepted");
    if (!hasAcceptedTerms) {
      setOpen(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem("termsAccepted", "true");
    setOpen(false);
  };

  return (
    <AlertDialog open={open}>
      <AlertDialogContent className="max-w-2xl max-h-[80vh]">
        <AlertDialogHeader>
          <AlertDialogTitle className="text-2xl">
            Términos y Condiciones de Uso
          </AlertDialogTitle>
          <AlertDialogDescription>
            Por favor, lee y acepta nuestros términos y condiciones para continuar usando Between.
          </AlertDialogDescription>
        </AlertDialogHeader>
        
        <ScrollArea className="h-[400px] pr-4">
          <div className="space-y-4 text-sm">
            <section>
              <h3 className="font-semibold text-base mb-2">1. Aceptación de los Términos</h3>
              <p className="text-muted-foreground">
                Al acceder y utilizar Between, aceptas estar sujeto a estos términos y condiciones de uso, 
                todas las leyes y regulaciones aplicables, y aceptas que eres responsable del cumplimiento 
                de las leyes locales aplicables.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-base mb-2">2. Uso de la Plataforma</h3>
              <p className="text-muted-foreground">
                Between es una plataforma diseñada para conectar profesionales con oportunidades laborales 
                y recursos educativos. Te comprometes a utilizar la plataforma de manera responsable y 
                respetuosa con otros usuarios.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-base mb-2">3. Privacidad y Datos</h3>
              <p className="text-muted-foreground">
                Nos comprometemos a proteger tu privacidad. La información personal que proporciones será 
                utilizada únicamente para mejorar tu experiencia en la plataforma. No compartiremos tu 
                información con terceros sin tu consentimiento explícito.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-base mb-2">4. Contenido del Usuario</h3>
              <p className="text-muted-foreground">
                Eres responsable del contenido que publiques en la plataforma. No debes publicar contenido 
                ofensivo, ilegal o que infrinja los derechos de terceros. Nos reservamos el derecho de 
                eliminar cualquier contenido que viole estas normas.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-base mb-2">5. Propiedad Intelectual</h3>
              <p className="text-muted-foreground">
                Todo el contenido de Between, incluyendo textos, gráficos, logotipos y software, es 
                propiedad de Between o sus licenciantes y está protegido por las leyes de propiedad 
                intelectual.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-base mb-2">6. Limitación de Responsabilidad</h3>
              <p className="text-muted-foreground">
                Between se proporciona "tal cual". No garantizamos que la plataforma esté libre de errores 
                o interrupciones. No seremos responsables por daños indirectos, incidentales o 
                consecuentes derivados del uso de la plataforma.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-base mb-2">7. Modificaciones</h3>
              <p className="text-muted-foreground">
                Nos reservamos el derecho de modificar estos términos en cualquier momento. Las 
                modificaciones entrarán en vigor inmediatamente después de su publicación en la plataforma.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-base mb-2">8. Contacto</h3>
              <p className="text-muted-foreground">
                Si tienes preguntas sobre estos términos, puedes contactarnos a través de nuestros 
                canales de soporte en la plataforma.
              </p>
            </section>
          </div>
        </ScrollArea>

        <AlertDialogFooter>
          <AlertDialogAction 
            onClick={handleAccept}
            data-testid="button-accept-terms"
            className="w-full sm:w-auto"
          >
            <span className="hidden sm:inline">Acepto los Términos y Condiciones</span>
            <span className="sm:hidden">Aceptar</span>
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
