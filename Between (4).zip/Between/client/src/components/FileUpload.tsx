import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Upload, X, FileText } from "lucide-react";

interface FileUploadProps {
  label: string;
  accept?: string;
  optional?: boolean;
  onFileSelect?: (file: File | null) => void;
}

export default function FileUpload({ label, accept = ".pdf,.doc,.docx", optional = false, onFileSelect }: FileUploadProps) {
  const [file, setFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleFileChange = (selectedFile: File | null) => {
    setFile(selectedFile);
    onFileSelect?.(selectedFile);
    console.log('File selected:', selectedFile?.name);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile) {
      handleFileChange(droppedFile);
    }
  };

  return (
    <div className="space-y-2">
      <label className="text-sm font-medium">
        {label} {optional && <span className="text-muted-foreground">(Opcional)</span>}
      </label>
      
      {!file ? (
        <Card
          className={`border-2 border-dashed p-8 text-center cursor-pointer hover-elevate transition-colors ${
            isDragging ? 'border-primary bg-primary/5' : ''
          }`}
          onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          onClick={() => document.getElementById(`file-input-${label}`)?.click()}
          data-testid={`dropzone-${label.toLowerCase().replace(/\s/g, '-')}`}
        >
          <Upload className="h-10 w-10 mx-auto mb-4 text-muted-foreground" />
          <p className="text-sm font-medium mb-1">
            Arrastra tu archivo aquí o haz clic para seleccionar
          </p>
          <p className="text-xs text-muted-foreground">
            Formatos aceptados: {accept}
          </p>
          <input
            id={`file-input-${label}`}
            type="file"
            className="hidden"
            accept={accept}
            onChange={(e) => handleFileChange(e.target.files?.[0] || null)}
            data-testid={`input-file-${label.toLowerCase().replace(/\s/g, '-')}`}
          />
        </Card>
      ) : (
        <Card className="p-4">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3 flex-1 min-w-0">
              <FileText className="h-8 w-8 text-primary flex-shrink-0" />
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium truncate" data-testid={`text-filename-${label.toLowerCase().replace(/\s/g, '-')}`}>
                  {file.name}
                </p>
                <p className="text-xs text-muted-foreground">
                  {(file.size / 1024).toFixed(2)} KB
                </p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => handleFileChange(null)}
              data-testid={`button-remove-${label.toLowerCase().replace(/\s/g, '-')}`}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </Card>
      )}
    </div>
  );
}
