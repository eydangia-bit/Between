import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Search, Menu, User, BookOpen, Briefcase, Users } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useState } from "react";

export default function Header() {
  const [location, setLocation] = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      setLocation(`/jobs?search=${encodeURIComponent(searchTerm.trim())}`);
    } else {
      setLocation("/jobs");
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between gap-4">
          <Link href="/" className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary text-primary-foreground">
              <span className="text-lg font-bold">B</span>
            </div>
            <span className="text-xl font-bold">Between</span>
          </Link>

          <nav className="hidden md:flex items-center gap-6">
            <Link href="/jobs" className={`flex items-center gap-2 text-sm font-medium transition-colors hover:text-primary ${location === '/jobs' ? 'text-primary' : 'text-foreground'}`} data-testid="link-jobs">
              <Briefcase className="h-4 w-4" />
              Empleos
            </Link>
            <Link href="/courses" className={`flex items-center gap-2 text-sm font-medium transition-colors hover:text-primary ${location === '/courses' ? 'text-primary' : 'text-foreground'}`} data-testid="link-courses">
              <BookOpen className="h-4 w-4" />
              Recursos
            </Link>
            <Link href="/community" className={`flex items-center gap-2 text-sm font-medium transition-colors hover:text-primary ${location === '/community' ? 'text-primary' : 'text-foreground'}`} data-testid="link-community">
              <Users className="h-4 w-4" />
              Comunidad
            </Link>
          </nav>

          <div className="hidden lg:flex flex-1 max-w-sm">
            <form onSubmit={handleSearch} className="relative w-full">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Buscar empleos..."
                className="pl-9"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                data-testid="input-search"
              />
            </form>
          </div>

          <div className="flex items-center gap-2">
            <Link href="/profile">
              <Button variant="ghost" size="icon" data-testid="button-profile">
                <User className="h-5 w-5" />
              </Button>
            </Link>
            <Link href="/login">
              <Button className="hidden md:inline-flex" data-testid="button-login">
                Iniciar Sesión
              </Button>
            </Link>
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              data-testid="button-menu"
            >
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {isMenuOpen && (
          <div className="md:hidden border-t py-4">
            <nav className="flex flex-col gap-4">
              <Link href="/jobs" className="flex items-center gap-2 text-sm font-medium" data-testid="link-mobile-jobs">
                <Briefcase className="h-4 w-4" />
                Empleos
              </Link>
              <Link href="/courses" className="flex items-center gap-2 text-sm font-medium" data-testid="link-mobile-courses">
                <BookOpen className="h-4 w-4" />
                Recursos
              </Link>
              <Link href="/community" className="flex items-center gap-2 text-sm font-medium" data-testid="link-mobile-community">
                <Users className="h-4 w-4" />
                Comunidad
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
