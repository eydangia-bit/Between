import JobMap from '../JobMap';

export default function JobMapExample() {
  const mockJobs = [
    { id: '1', title: 'Desarrollador Web', company: 'Tech SA', location: 'Lima', lat: -12.0464, lng: -77.0428 },
    { id: '2', title: 'Diseñador UX', company: 'Design Co', location: 'Arequipa', lat: -16.4090, lng: -71.5375 },
    { id: '3', title: 'Contador', company: 'Finance Inc', location: 'Cusco', lat: -13.5319, lng: -71.9675 },
    { id: '4', title: 'Vendedor', company: 'Retail Ltd', location: 'Trujillo', lat: -8.1116, lng: -79.0288 },
  ];

  return (
    <div className="p-6">
      <JobMap jobs={mockJobs} />
    </div>
  );
}
