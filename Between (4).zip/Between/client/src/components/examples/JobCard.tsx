import JobCard from '../JobCard';

export default function JobCardExample() {
  return (
    <div className="p-6 max-w-sm">
      <JobCard
        id="1"
        title="Desarrollador Full Stack"
        company="TechPeru SAC"
        location="Lima, Perú"
        salary="S/. 3,500 - S/. 5,000"
        schedule="Lunes a Viernes, 9:00 AM - 6:00 PM"
        type="Tiempo Completo"
        postedDate="hace 2 días"
        description="Buscamos desarrollador con experiencia en React y Node.js para unirse a nuestro equipo de desarrollo de productos digitales."
      />
    </div>
  );
}
