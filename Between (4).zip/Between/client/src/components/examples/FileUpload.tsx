import FileUpload from '../FileUpload';

export default function FileUploadExample() {
  return (
    <div className="p-6 max-w-md space-y-6">
      <FileUpload label="Curriculum Vitae (CV)" />
      <FileUpload label="Documentos Adicionales" optional />
      <FileUpload label="Certificado de Discapacidad" optional accept=".pdf" />
    </div>
  );
}
