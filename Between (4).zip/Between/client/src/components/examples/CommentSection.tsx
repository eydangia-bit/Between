import CommentSection from '../CommentSection';

export default function CommentSectionExample() {
  const mockComments = [
    {
      id: '1',
      author: 'María González',
      content: '¡Excelente plataforma! Encontré trabajo en solo 2 semanas.',
      timestamp: 'hace 2 horas',
      likes: 12,
    },
    {
      id: '2',
      author: 'Carlos Pérez',
      content: 'Los cursos de preparación me ayudaron mucho con las entrevistas.',
      timestamp: 'hace 5 horas',
      likes: 8,
    },
  ];

  return (
    <div className="p-6 max-w-2xl">
      <CommentSection comments={mockComments} />
    </div>
  );
}
