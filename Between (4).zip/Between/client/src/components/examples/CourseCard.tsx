import CourseCard from '../CourseCard';
import courseImage from '@assets/generated_images/Training_workshop_classroom_115620e8.png';

export default function CourseCardExample() {
  return (
    <div className="p-6 max-w-sm">
      <CourseCard
        id="1"
        title="Cómo Crear un Currículum Profesional"
        category="Preparación Laboral"
        duration="2 horas"
        level="Principiante"
        description="Aprende a diseñar un currículum que destaque tus habilidades y experiencia de manera efectiva."
        imageUrl={courseImage}
      />
    </div>
  );
}
