import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight, Briefcase, GraduationCap } from "lucide-react";
import heroImage from "@assets/generated_images/Hero_diverse_Peruvian_workers_0eae57f2.png";

export default function Hero() {
  return (
    <section className="relative h-[600px] flex items-center justify-center overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroImage})` }}
      />
      <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-black/30" />
      
      <div className="relative z-10 container mx-auto px-4">
        <div className="max-w-3xl">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6">
            Tu próximo empleo está entre nosotros
          </h1>
          <p className="text-lg md:text-xl text-white/90 mb-8 leading-relaxed">
            Conectamos talento peruano con oportunidades reales. Encuentra trabajo, desarrolla habilidades y construye tu futuro profesional.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link href="/jobs">
              <Button size="lg" className="gap-2" data-testid="button-find-jobs">
                <Briefcase className="h-5 w-5" />
                Buscar Empleos
                <ArrowRight className="h-5 w-5" />
              </Button>
            </Link>
            <Link href="/courses">
              <Button 
                size="lg" 
                variant="outline" 
                className="gap-2 backdrop-blur-sm bg-white/90 hover:bg-white"
                data-testid="button-learn-skills"
              >
                <GraduationCap className="h-5 w-5" />
                Aprender Nuevas Habilidades
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
