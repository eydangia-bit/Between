import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MapPin, Navigation, X, ZoomIn, ZoomOut } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

export interface JobLocation {
  id: string;
  title: string;
  company: string;
  location: string;
  lat: number;
  lng: number;
}

interface JobMapProps {
  jobs: JobLocation[];
}

interface UserLocation {
  lat: number;
  lng: number;
}

const jobIcon = L.divIcon({
  className: "custom-job-marker",
  html: `
    <div class="flex h-10 w-10 items-center justify-center rounded-full bg-blue-600 text-white shadow-lg border-2 border-white">
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"></path>
        <circle cx="12" cy="10" r="3"></circle>
      </svg>
    </div>
  `,
  iconSize: [40, 40],
  iconAnchor: [20, 40],
  popupAnchor: [0, -40],
});

const userIcon = L.divIcon({
  className: "custom-user-marker",
  html: `
    <div class="relative">
      <div class="flex h-12 w-12 items-center justify-center rounded-full bg-green-600 text-white shadow-xl border-4 border-white animate-pulse">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"></path>
          <circle cx="12" cy="7" r="4"></circle>
        </svg>
      </div>
      <div class="absolute inset-0 rounded-full bg-green-400 opacity-30 animate-ping"></div>
    </div>
  `,
  iconSize: [48, 48],
  iconAnchor: [24, 48],
  popupAnchor: [0, -48],
});

function MapControls() {
  const map = useMap();
  
  return (
    <div className="absolute top-4 right-4 z-[1000] flex flex-col gap-2">
      <Button
        size="icon"
        variant="secondary"
        onClick={() => map.zoomIn()}
        data-testid="button-zoom-in"
      >
        <ZoomIn className="h-4 w-4" />
      </Button>
      <Button
        size="icon"
        variant="secondary"
        onClick={() => map.zoomOut()}
        data-testid="button-zoom-out"
      >
        <ZoomOut className="h-4 w-4" />
      </Button>
    </div>
  );
}

function UserLocationMarker({ location }: { location: UserLocation }) {
  const map = useMap();

  useEffect(() => {
    map.flyTo([location.lat, location.lng], 10, {
      duration: 1.5,
    });
  }, [location, map]);

  return (
    <Marker position={[location.lat, location.lng]} icon={userIcon}>
      <Popup>
        <div className="text-center">
          <p className="font-semibold">Tú estás aquí</p>
        </div>
      </Popup>
    </Marker>
  );
}

export default function JobMap({ jobs }: JobMapProps) {
  const [selectedJob, setSelectedJob] = useState<string | null>(null);
  const [userLocation, setUserLocation] = useState<UserLocation | null>(null);
  const [isLoadingLocation, setIsLoadingLocation] = useState(false);
  const [locationError, setLocationError] = useState<string | null>(null);
  const { toast } = useToast();
  const mapRef = useRef<L.Map | null>(null);

  const peruCenter: [number, number] = [-9.19, -75.0152];
  const defaultZoom = 5;

  const requestUserLocation = () => {
    if (!navigator.geolocation) {
      const errorMsg = "Tu navegador no soporta geolocalización";
      setLocationError(errorMsg);
      toast({
        title: "Error",
        description: errorMsg,
        variant: "destructive",
      });
      return;
    }

    setIsLoadingLocation(true);
    setLocationError(null);

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const location = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        };
        setUserLocation(location);
        setIsLoadingLocation(false);
        toast({
          title: "Ubicación activada",
          description: "Tu ubicación se ha marcado en el mapa",
        });
      },
      (error) => {
        setIsLoadingLocation(false);
        let errorMsg = "No se pudo obtener tu ubicación";
        
        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorMsg = "Permiso de ubicación denegado. Por favor, permite el acceso a tu ubicación.";
            break;
          case error.POSITION_UNAVAILABLE:
            errorMsg = "Información de ubicación no disponible";
            break;
          case error.TIMEOUT:
            errorMsg = "La solicitud de ubicación expiró";
            break;
        }
        
        setLocationError(errorMsg);
        toast({
          title: "Error de ubicación",
          description: errorMsg,
          variant: "destructive",
        });
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0,
      }
    );
  };

  const clearUserLocation = () => {
    setUserLocation(null);
    setLocationError(null);
    toast({
      title: "Ubicación desactivada",
      description: "Tu ubicación ha sido eliminada del mapa",
    });
  };

  return (
    <div className="relative">
      <Card className="overflow-hidden">
        <div className="relative h-[600px]">
          <div className="absolute top-4 left-4 z-[1000] space-y-2">
            <Card className="p-3">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-primary" />
                  <span className="text-sm font-medium">{jobs.length} empleos</span>
                </div>
                {userLocation && (
                  <div className="flex items-center gap-2">
                    <Navigation className="h-4 w-4 text-green-600 dark:text-green-400" />
                    <span className="text-sm font-medium">Tu ubicación</span>
                  </div>
                )}
              </div>
            </Card>

            {!userLocation ? (
              <Button
                onClick={requestUserLocation}
                disabled={isLoadingLocation}
                className="w-full"
                data-testid="button-enable-location"
              >
                <Navigation className="h-4 w-4 mr-2" />
                {isLoadingLocation ? "Obteniendo..." : "Activar mi ubicación"}
              </Button>
            ) : (
              <Button
                onClick={clearUserLocation}
                variant="destructive"
                className="w-full"
                data-testid="button-disable-location"
              >
                <X className="h-4 w-4 mr-2" />
                Desactivar ubicación
              </Button>
            )}
          </div>

          <MapContainer
            center={peruCenter}
            zoom={defaultZoom}
            style={{ height: "100%", width: "100%" }}
            ref={mapRef}
            data-testid="map-container"
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            
            {jobs.map((job) => (
              <Marker
                key={job.id}
                position={[job.lat, job.lng]}
                icon={jobIcon}
                eventHandlers={{
                  click: () => setSelectedJob(job.id),
                }}
              >
                <Popup>
                  <div className="min-w-[200px]">
                    <h3 className="font-semibold text-base">{job.title}</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{job.company}</p>
                    <div className="flex items-center gap-1 mt-1 text-sm text-gray-500">
                      <MapPin className="h-3 w-3" />
                      <span>{job.location}</span>
                    </div>
                  </div>
                </Popup>
              </Marker>
            ))}

            {userLocation && <UserLocationMarker location={userLocation} />}
            
            <MapControls />
          </MapContainer>
        </div>
      </Card>

      {selectedJob && (
        <div className="mt-4">
          <Card className="p-4">
            {(() => {
              const job = jobs.find((j) => j.id === selectedJob);
              if (!job) return null;
              return (
                <div className="space-y-2">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h3 className="font-semibold text-lg" data-testid={`text-selected-job-title-${selectedJob}`}>
                        {job.title}
                      </h3>
                      <p className="text-sm text-muted-foreground">{job.company}</p>
                      <div className="flex items-center gap-1 mt-1 text-sm text-muted-foreground">
                        <MapPin className="h-3 w-3" />
                        <span>{job.location}</span>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      onClick={() => setSelectedJob(null)}
                      variant="ghost"
                      data-testid="button-close-job-details"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              );
            })()}
          </Card>
        </div>
      )}

      {locationError && (
        <div className="mt-4">
          <Card className="p-4 bg-destructive/10 border-destructive">
            <div className="flex items-start gap-3">
              <MapPin className="h-5 w-5 text-destructive mt-0.5" />
              <div>
                <p className="text-sm font-medium text-destructive">
                  Error de ubicación
                </p>
                <p className="text-sm text-destructive/90 mt-1">
                  {locationError}
                </p>
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
