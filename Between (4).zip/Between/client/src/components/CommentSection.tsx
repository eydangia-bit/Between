import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useState } from "react";
import { MessageSquare, ThumbsUp } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface Comment {
  id: string;
  author: string;
  content: string;
  timestamp: string;
  likes: number;
}

interface CommentSectionProps {
  comments: Comment[];
}

export default function CommentSection({ comments }: CommentSectionProps) {
  const [newComment, setNewComment] = useState("");
  const { toast } = useToast();

  const createCommentMutation = useMutation({
    mutationFn: async (content: string) => {
      const currentUser = localStorage.getItem('currentUser') || 'Usuario';
      return await apiRequest('POST', '/api/comments', {
        author: currentUser,
        content
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/comments'] });
      setNewComment("");
      toast({
        title: "Comentario publicado",
        description: "Tu comentario ha sido publicado exitosamente."
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "No se pudo publicar el comentario.",
        variant: "destructive"
      });
    }
  });

  const likeCommentMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest('POST', `/api/comments/${id}/like`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/comments'] });
    }
  });

  const handleSubmit = () => {
    if (!newComment.trim()) return;
    createCommentMutation.mutate(newComment);
  };

  const handleLike = (id: string) => {
    likeCommentMutation.mutate(id);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <MessageSquare className="h-5 w-5" />
            Comentarios ({comments.length})
          </h3>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <Textarea
              placeholder="Comparte tu opinión o pregunta..."
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              rows={3}
              data-testid="textarea-comment"
            />
            <Button 
              onClick={handleSubmit} 
              disabled={createCommentMutation.isPending}
              data-testid="button-post-comment"
              className="w-full sm:w-auto"
            >
              {createCommentMutation.isPending ? "Publicando..." : (
                <>
                  <span className="hidden sm:inline">Publicar Comentario</span>
                  <span className="sm:hidden">Publicar</span>
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-4">
        {comments.map((comment) => (
          <Card key={comment.id} data-testid={`card-comment-${comment.id}`}>
            <CardContent className="pt-6">
              <div className="flex gap-4">
                <Avatar>
                  <AvatarFallback>{comment.author.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="flex-1 space-y-2">
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <p className="font-medium" data-testid={`text-author-${comment.id}`}>
                      {comment.author}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {comment.timestamp}
                    </p>
                  </div>
                  <p className="text-sm" data-testid={`text-content-${comment.id}`}>
                    {comment.content}
                  </p>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleLike(comment.id)}
                    className="gap-2 -ml-2"
                    data-testid={`button-like-${comment.id}`}
                  >
                    <ThumbsUp className="h-4 w-4" />
                    <span>{comment.likes}</span>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
