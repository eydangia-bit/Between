import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, DollarSign, Calendar, Clock } from "lucide-react";
import { Link } from "wouter";

export interface JobCardProps {
  id: string;
  title: string;
  company: string;
  location: string;
  salary: string;
  schedule: string;
  type: string;
  postedDate: string;
  description: string;
}

export default function JobCard({ id, title, company, location, salary, schedule, type, postedDate, description }: JobCardProps) {
  return (
    <Card className="hover-elevate active-elevate-2 transition-all h-full flex flex-col" data-testid={`card-job-${id}`}>
      <CardHeader className="space-y-2">
        <div className="flex items-start justify-between gap-2">
          <h3 className="text-lg font-semibold leading-tight line-clamp-2" data-testid={`text-job-title-${id}`}>
            {title}
          </h3>
          <Badge variant="secondary" data-testid={`badge-job-type-${id}`}>
            {type}
          </Badge>
        </div>
        <p className="text-sm font-medium text-muted-foreground" data-testid={`text-company-${id}`}>
          {company}
        </p>
      </CardHeader>
      
      <CardContent className="flex-1 space-y-3">
        <p className="text-sm text-muted-foreground line-clamp-3">
          {description}
        </p>
        
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-sm">
            <MapPin className="h-4 w-4 text-muted-foreground" />
            <span data-testid={`text-location-${id}`}>{location}</span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <DollarSign className="h-4 w-4 text-muted-foreground" />
            <span className="font-medium" data-testid={`text-salary-${id}`}>{salary}</span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <Clock className="h-4 w-4 text-muted-foreground" />
            <span data-testid={`text-schedule-${id}`}>{schedule}</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Calendar className="h-4 w-4" />
            <span data-testid={`text-posted-${id}`}>Publicado {postedDate}</span>
          </div>
        </div>
      </CardContent>
      
      <CardFooter>
        <Link href={`/jobs/${id}`} className="w-full">
          <Button className="w-full" data-testid={`button-apply-${id}`}>
            Ver Detalles y Postular
          </Button>
        </Link>
      </CardFooter>
    </Card>
  );
}
