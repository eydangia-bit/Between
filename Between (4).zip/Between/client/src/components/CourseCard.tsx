import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, BarChart } from "lucide-react";
import { Link } from "wouter";

export interface CourseCardProps {
  id: string;
  title: string;
  category: string;
  duration: string;
  level: "Principiante" | "Intermedio" | "Avanzado";
  description: string;
  imageUrl: string;
}

export default function CourseCard({ id, title, category, duration, level, description, imageUrl }: CourseCardProps) {
  const levelColors = {
    Principiante: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
    Intermedio: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400",
    Avanzado: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
  };

  return (
    <Card className="hover-elevate active-elevate-2 transition-all h-full flex flex-col overflow-hidden" data-testid={`card-course-${id}`}>
      <div className="relative h-48 overflow-hidden">
        <img
          src={imageUrl}
          alt={title}
          className="w-full h-full object-cover"
        />
        <div className="absolute top-3 right-3">
          <Badge variant="secondary" data-testid={`badge-category-${id}`}>
            {category}
          </Badge>
        </div>
      </div>
      
      <CardHeader className="space-y-2">
        <h3 className="text-lg font-semibold leading-tight line-clamp-2" data-testid={`text-course-title-${id}`}>
          {title}
        </h3>
      </CardHeader>
      
      <CardContent className="flex-1 space-y-4">
        <p className="text-sm text-muted-foreground line-clamp-3">
          {description}
        </p>
        
        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-1">
            <Clock className="h-4 w-4 text-muted-foreground" />
            <span data-testid={`text-duration-${id}`}>{duration}</span>
          </div>
          <div className="flex items-center gap-1">
            <BarChart className="h-4 w-4 text-muted-foreground" />
            <Badge className={levelColors[level]} data-testid={`badge-level-${id}`}>
              {level}
            </Badge>
          </div>
        </div>
      </CardContent>
      
      <CardFooter>
        <Link href={`/courses/${id}`} className="w-full">
          <Button className="w-full" data-testid={`button-start-${id}`}>
            Comenzar Curso
          </Button>
        </Link>
      </CardFooter>
    </Card>
  );
}
