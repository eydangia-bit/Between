export interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  salary: string;
  schedule: string;
  type: string;
  postedDate: string;
  description: string;
  lat: number;
  lng: number;
  responsibilities?: string[];
  requirements?: string[];
  benefits?: string[];
}

export const allJobs: Job[] = [
  {
    id: '1',
    title: 'Desarrollador Full Stack',
    company: 'TechPeru SAC',
    location: 'Lima, Perú',
    salary: 'S/. 3,500 - S/. 5,000',
    schedule: 'Lunes a Viernes, 9:00 AM - 6:00 PM',
    type: 'Tiempo Completo',
    postedDate: 'hace 2 días',
    description: 'Buscamos un desarrollador full stack talentoso y apasionado para unirse a nuestro equipo de desarrollo de productos digitales. El candidato ideal tendrá experiencia comprobada en React, Node.js y bases de datos relacionales.',
    lat: -12.0464,
    lng: -77.0428,
    responsibilities: [
      'Desarrollar y mantener aplicaciones web utilizando React y Node.js',
      'Colaborar con diseñadores UX/UI para implementar interfaces de usuario',
      'Escribir código limpio, mantenible y bien documentado',
      'Participar en revisiones de código y sesiones de pair programming',
      'Optimizar aplicaciones para máximo rendimiento y escalabilidad'
    ],
    requirements: [
      '3+ años de experiencia en desarrollo full stack',
      'Dominio de React, Node.js y TypeScript',
      'Experiencia con bases de datos SQL y NoSQL',
      'Conocimientos de Git y metodologías ágiles',
      'Excelentes habilidades de comunicación'
    ],
    benefits: [
      'Salario competitivo y bonos por desempeño',
      'Seguro de salud para ti y tu familia',
      'Oportunidades de capacitación y desarrollo profesional',
      'Ambiente de trabajo colaborativo y moderno',
      'Flexibilidad horaria y posibilidad de trabajo remoto'
    ]
  },
  {
    id: '2',
    title: 'Asistente Administrativo',
    company: 'Corporación Andina',
    location: 'Arequipa, Perú',
    salary: 'S/. 1,800 - S/. 2,500',
    schedule: 'Lunes a Viernes, 8:00 AM - 5:00 PM',
    type: 'Tiempo Completo',
    postedDate: 'hace 1 día',
    description: 'Empresa líder en el sector retail busca asistente administrativo con conocimientos en Microsoft Office y atención al cliente para apoyar en la gestión diaria de la oficina.',
    lat: -16.4090,
    lng: -71.5375,
    responsibilities: [
      'Gestionar correspondencia y archivo de documentos',
      'Atender llamadas telefónicas y coordinar reuniones',
      'Apoyar en la elaboración de informes administrativos',
      'Mantener actualizada la base de datos de clientes',
      'Coordinar logística de eventos y reuniones corporativas'
    ],
    requirements: [
      '1+ año de experiencia en puestos administrativos',
      'Dominio de Microsoft Office (Word, Excel, PowerPoint)',
      'Excelente organización y atención al detalle',
      'Habilidades de comunicación oral y escrita',
      'Estudios técnicos o universitarios en administración'
    ],
    benefits: [
      'Salario competitivo acorde al mercado',
      'Seguro de salud EsSalud',
      'Capacitación constante',
      'Buen ambiente laboral',
      'Oportunidades de crecimiento'
    ]
  },
  {
    id: '3',
    title: 'Diseñador Gráfico',
    company: 'Creativa Studio',
    location: 'Cusco, Perú',
    salary: 'S/. 2,200 - S/. 3,200',
    schedule: 'Lunes a Sábado, 9:00 AM - 6:00 PM',
    type: 'Medio Tiempo',
    postedDate: 'hace 3 días',
    description: 'Agencia de marketing digital busca diseñador creativo con experiencia en Adobe Creative Suite y diseño web para crear contenido visual impactante para nuestros clientes.',
    lat: -13.5319,
    lng: -71.9675,
    responsibilities: [
      'Crear diseños para redes sociales y campañas publicitarias',
      'Desarrollar identidad visual para marcas',
      'Diseñar materiales impresos y digitales',
      'Colaborar con el equipo de marketing en estrategias visuales',
      'Mantener consistencia en la línea gráfica de los proyectos'
    ],
    requirements: [
      '2+ años de experiencia como diseñador gráfico',
      'Dominio de Adobe Photoshop, Illustrator e InDesign',
      'Conocimientos de diseño web y UI/UX',
      'Portfolio con trabajos previos',
      'Creatividad y capacidad para trabajar bajo presión'
    ],
    benefits: [
      'Salario acorde a experiencia',
      'Ambiente creativo y dinámico',
      'Proyectos variados y desafiantes',
      'Horario flexible',
      'Posibilidad de trabajo remoto'
    ]
  },
  {
    id: '4',
    title: 'Contador Senior',
    company: 'Finanzas Corporativas SAC',
    location: 'Lima, Perú',
    salary: 'S/. 4,000 - S/. 6,000',
    schedule: 'Lunes a Viernes, 9:00 AM - 6:00 PM',
    type: 'Tiempo Completo',
    postedDate: 'hace 4 días',
    description: 'Importante empresa del sector financiero requiere contador con experiencia en auditoría y normativa tributaria peruana para liderar el área contable.',
    lat: -12.0931,
    lng: -76.9998,
    responsibilities: [
      'Llevar la contabilidad general de la empresa',
      'Preparar estados financieros mensuales y anuales',
      'Coordinar auditorías internas y externas',
      'Gestionar declaraciones tributarias mensuales',
      'Supervisar al equipo contable'
    ],
    requirements: [
      'Título de Contador Público Colegiado',
      '5+ años de experiencia en contabilidad',
      'Conocimiento de normativa tributaria peruana',
      'Experiencia con sistemas contables ERP',
      'Disponibilidad para trabajar en cierre contable'
    ],
    benefits: [
      'Salario competitivo',
      'Bonos por cumplimiento de objetivos',
      'Seguro de salud privado',
      'Capacitaciones especializadas',
      'Línea de carrera definida'
    ]
  },
  {
    id: '5',
    title: 'Vendedor de Tienda',
    company: 'Retail Express',
    location: 'Trujillo, Perú',
    salary: 'S/. 1,200 - S/. 1,800',
    schedule: 'Martes a Domingo, 10:00 AM - 7:00 PM',
    type: 'Tiempo Completo',
    postedDate: 'hace 1 semana',
    description: 'Cadena de tiendas retail busca vendedor con experiencia en atención al cliente y manejo de caja para nuestras tiendas en Trujillo.',
    lat: -8.1116,
    lng: -79.0288,
    responsibilities: [
      'Atender y asesorar a clientes en la tienda',
      'Realizar ventas y manejar caja registradora',
      'Mantener la tienda ordenada y limpia',
      'Reponer mercadería en los anaqueles',
      'Cumplir con metas de ventas mensuales'
    ],
    requirements: [
      'Secundaria completa',
      'Experiencia mínima 6 meses en ventas',
      'Buena presencia y trato amable',
      'Disponibilidad para trabajar fines de semana',
      'Proactividad y orientación al cliente'
    ],
    benefits: [
      'Sueldo fijo más comisiones por ventas',
      'Descuentos en productos de la tienda',
      'Seguro EsSalud',
      'Capacitación en ventas',
      'Oportunidad de crecimiento'
    ]
  },
  {
    id: '6',
    title: 'Ingeniero de Software',
    company: 'Innovation Labs',
    location: 'Lima, Perú',
    salary: 'S/. 5,000 - S/. 7,500',
    schedule: 'Lunes a Viernes, Flexible',
    type: 'Remoto',
    postedDate: 'hace 2 días',
    description: 'Startup tecnológica busca ingeniero de software con experiencia en arquitectura de sistemas y cloud computing para desarrollar soluciones innovadoras.',
    lat: -12.1200,
    lng: -77.0350,
    responsibilities: [
      'Diseñar arquitectura de sistemas escalables',
      'Desarrollar microservicios en la nube',
      'Implementar CI/CD pipelines',
      'Liderar proyectos técnicos',
      'Mentoría a desarrolladores junior'
    ],
    requirements: [
      '5+ años de experiencia en desarrollo de software',
      'Experiencia con AWS o Azure',
      'Conocimientos de Docker y Kubernetes',
      'Dominio de al menos un lenguaje backend (Python, Java, Go)',
      'Experiencia en arquitectura de microservicios'
    ],
    benefits: [
      'Salario competitivo',
      'Trabajo 100% remoto',
      'Equipos de última generación',
      'Stock options',
      'Presupuesto para capacitación'
    ]
  },
  {
    id: '7',
    title: 'Gerente de Ventas',
    company: 'Comercial del Sur',
    location: 'Arequipa, Perú',
    salary: 'S/. 4,500 - S/. 6,500',
    schedule: 'Lunes a Viernes, 9:00 AM - 6:00 PM',
    type: 'Tiempo Completo',
    postedDate: 'hace 5 días',
    description: 'Empresa líder busca gerente de ventas con experiencia en retail y manejo de equipos comerciales para impulsar el crecimiento en la región sur.',
    lat: -16.3988,
    lng: -71.5350,
    responsibilities: [
      'Liderar y motivar al equipo de ventas',
      'Desarrollar estrategias comerciales',
      'Gestionar relaciones con clientes clave',
      'Analizar métricas de ventas y KPIs',
      'Cumplir y superar objetivos mensuales'
    ],
    requirements: [
      '3+ años como gerente o supervisor de ventas',
      'Experiencia en sector retail',
      'Habilidades de liderazgo comprobadas',
      'Orientación a resultados',
      'Licenciatura en Administración o afines'
    ],
    benefits: [
      'Salario competitivo más bonos',
      'Auto de la empresa',
      'Seguro de salud privado',
      'Capacitación en liderazgo',
      'Plan de crecimiento profesional'
    ]
  },
  {
    id: '8',
    title: 'Analista de Marketing',
    company: 'Digital Marketing Co',
    location: 'Lima, Perú',
    salary: 'S/. 2,800 - S/. 4,000',
    schedule: 'Lunes a Viernes, 9:00 AM - 6:00 PM',
    type: 'Remoto',
    postedDate: 'hace 3 días',
    description: 'Agencia de marketing busca analista para gestionar campañas digitales y análisis de métricas para clientes de diversos sectores.',
    lat: -12.0700,
    lng: -77.0500,
    responsibilities: [
      'Planificar y ejecutar campañas digitales',
      'Analizar métricas y generar reportes',
      'Gestionar presupuestos de publicidad digital',
      'Optimizar campañas de Google Ads y Facebook Ads',
      'Coordinar con el equipo creativo'
    ],
    requirements: [
      '2+ años de experiencia en marketing digital',
      'Conocimiento de Google Analytics y Google Ads',
      'Experiencia con redes sociales',
      'Capacidad analítica y orientación a resultados',
      'Estudios en Marketing, Comunicaciones o afines'
    ],
    benefits: [
      'Trabajo remoto',
      'Salario competitivo',
      'Certificaciones en marketing digital',
      'Ambiente dinámico',
      'Proyectos variados'
    ]
  },
  {
    id: '9',
    title: 'Enfermera Profesional',
    company: 'Clínica San José',
    location: 'Lima, Perú',
    salary: 'S/. 2,500 - S/. 3,500',
    schedule: 'Turnos rotativos',
    type: 'Tiempo Completo',
    postedDate: 'hace 1 día',
    description: 'Clínica privada busca enfermera titulada y colegiada para brindar atención de calidad a nuestros pacientes en diferentes áreas.',
    lat: -12.0800,
    lng: -77.0200,
    responsibilities: [
      'Brindar atención y cuidados de enfermería',
      'Administrar medicamentos según prescripción médica',
      'Monitorear signos vitales de pacientes',
      'Asistir en procedimientos médicos',
      'Mantener registros de enfermería actualizados'
    ],
    requirements: [
      'Título de Licenciada en Enfermería',
      'Colegiatura vigente',
      'Experiencia mínima 1 año en clínicas u hospitales',
      'Certificación en BLS vigente',
      'Capacidad para trabajar bajo presión'
    ],
    benefits: [
      'Salario competitivo',
      'Seguro de salud',
      'Uniformes proporcionados',
      'Capacitaciones constantes',
      'Ambiente profesional'
    ]
  },
  {
    id: '10',
    title: 'Chef de Cocina',
    company: 'Restaurante Fusión',
    location: 'Cusco, Perú',
    salary: 'S/. 3,000 - S/. 4,500',
    schedule: 'Martes a Domingo, 11:00 AM - 11:00 PM',
    type: 'Tiempo Completo',
    postedDate: 'hace 2 días',
    description: 'Restaurante de alta cocina busca chef con experiencia en cocina peruana e internacional para liderar nuestra cocina.',
    lat: -13.5200,
    lng: -71.9700,
    responsibilities: [
      'Crear y supervisar la preparación de platos',
      'Diseñar menús y especiales del día',
      'Gestionar el equipo de cocina',
      'Controlar inventario y pedidos de insumos',
      'Garantizar estándares de calidad e higiene'
    ],
    requirements: [
      'Formación en gastronomía o cocina',
      '3+ años de experiencia como chef',
      'Conocimiento de cocina peruana e internacional',
      'Creatividad y pasión por la gastronomía',
      'Liderazgo y trabajo en equipo'
    ],
    benefits: [
      'Salario competitivo',
      'Alimentación incluida',
      'Propinas compartidas',
      'Ambiente creativo',
      'Reconocimiento por excelencia'
    ]
  },
  {
    id: '11',
    title: 'Profesor de Matemáticas',
    company: 'Colegio Santa Rosa',
    location: 'Trujillo, Perú',
    salary: 'S/. 2,000 - S/. 3,000',
    schedule: 'Lunes a Viernes, 7:30 AM - 3:00 PM',
    type: 'Tiempo Completo',
    postedDate: 'hace 1 semana',
    description: 'Institución educativa privada busca profesor de matemáticas para nivel secundaria con vocación de servicio y excelencia académica.',
    lat: -8.1100,
    lng: -79.0300,
    responsibilities: [
      'Enseñar matemáticas a nivel secundaria',
      'Preparar planes de clase y materiales didácticos',
      'Evaluar el progreso de los estudiantes',
      'Participar en reuniones de padres',
      'Apoyar en actividades extracurriculares'
    ],
    requirements: [
      'Título profesional en Educación o Matemáticas',
      'Experiencia mínima 2 años enseñando',
      'Vocación por la enseñanza',
      'Paciencia y habilidades comunicativas',
      'Conocimiento de metodologías activas'
    ],
    benefits: [
      'Salario estable',
      'Vacaciones escolares pagadas',
      'Capacitación pedagógica',
      'Seguro de salud',
      'Ambiente educativo positivo'
    ]
  },
  {
    id: '12',
    title: 'Mecánico Automotriz',
    company: 'Taller AutoServicio',
    location: 'Lima, Perú',
    salary: 'S/. 1,800 - S/. 2,800',
    schedule: 'Lunes a Sábado, 8:00 AM - 6:00 PM',
    type: 'Tiempo Completo',
    postedDate: 'hace 4 días',
    description: 'Taller automotriz establecido busca mecánico con experiencia en mantenimiento y reparación de vehículos livianos.',
    lat: -12.0600,
    lng: -77.0300,
    responsibilities: [
      'Diagnosticar y reparar fallas mecánicas',
      'Realizar mantenimientos preventivos',
      'Cambio de aceite y filtros',
      'Reparación de frenos y suspensión',
      'Mantener el área de trabajo limpia y ordenada'
    ],
    requirements: [
      'Estudios técnicos en mecánica automotriz',
      '2+ años de experiencia como mecánico',
      'Conocimiento de sistemas eléctricos',
      'Capacidad para trabajar en equipo',
      'Responsabilidad y puntualidad'
    ],
    benefits: [
      'Salario fijo más comisiones',
      'Herramientas proporcionadas',
      'Seguro EsSalud',
      'Uniformes',
      'Capacitación técnica'
    ]
  },
  {
    id: '13',
    title: 'Recepcionista de Hotel',
    company: 'Hotel Plaza Mayor',
    location: 'Arequipa, Perú',
    salary: 'S/. 1,500 - S/. 2,200',
    schedule: 'Turnos rotativos',
    type: 'Tiempo Completo',
    postedDate: 'hace 3 días',
    description: 'Hotel 4 estrellas busca recepcionista con excelente trato al cliente e inglés intermedio para atender a huéspedes nacionales e internacionales.',
    lat: -16.4000,
    lng: -71.5400,
    responsibilities: [
      'Atender check-in y check-out de huéspedes',
      'Brindar información turística',
      'Gestionar reservaciones',
      'Coordinar servicios adicionales',
      'Resolver consultas y quejas de huéspedes'
    ],
    requirements: [
      'Estudios en hotelería o turismo',
      'Inglés intermedio (indispensable)',
      '1+ año de experiencia en recepción',
      'Excelente presentación personal',
      'Habilidades de comunicación'
    ],
    benefits: [
      'Salario competitivo',
      'Propinas',
      'Descuentos en hospedaje',
      'Capacitación en servicio al cliente',
      'Buen ambiente laboral'
    ]
  },
  {
    id: '14',
    title: 'Electricista Industrial',
    company: 'Industrias del Norte SAC',
    location: 'Trujillo, Perú',
    salary: 'S/. 2,500 - S/. 3,800',
    schedule: 'Lunes a Viernes, 7:00 AM - 5:00 PM',
    type: 'Tiempo Completo',
    postedDate: 'hace 5 días',
    description: 'Empresa industrial busca electricista con experiencia en mantenimiento de maquinaria y sistemas eléctricos de media y baja tensión.',
    lat: -8.1200,
    lng: -79.0250,
    responsibilities: [
      'Realizar mantenimiento preventivo y correctivo',
      'Instalar y reparar sistemas eléctricos',
      'Diagnosticar fallas en maquinaria',
      'Leer e interpretar planos eléctricos',
      'Cumplir normas de seguridad industrial'
    ],
    requirements: [
      'Técnico en electricidad industrial',
      '3+ años de experiencia',
      'Conocimiento de tableros eléctricos',
      'Experiencia con PLCs',
      'Certificado de trabajo en altura'
    ],
    benefits: [
      'Salario competitivo',
      'Seguro complementario',
      'EPPs proporcionados',
      'Capacitación especializada',
      'Estabilidad laboral'
    ]
  },
  {
    id: '15',
    title: 'Asistente Social',
    company: 'Municipalidad de Cusco',
    location: 'Cusco, Perú',
    salary: 'S/. 2,200 - S/. 3,000',
    schedule: 'Lunes a Viernes, 8:00 AM - 5:00 PM',
    type: 'Tiempo Completo',
    postedDate: 'hace 1 semana',
    description: 'Municipalidad busca asistente social para programas de apoyo a familias vulnerables y desarrollo comunitario.',
    lat: -13.5300,
    lng: -71.9650,
    responsibilities: [
      'Evaluar situación socioeconómica de familias',
      'Diseñar y ejecutar programas sociales',
      'Coordinar con instituciones de apoyo',
      'Realizar visitas domiciliarias',
      'Elaborar informes sociales'
    ],
    requirements: [
      'Título de Trabajador Social',
      'Colegiatura vigente',
      '2+ años de experiencia en programas sociales',
      'Empatía y compromiso social',
      'Conocimiento de normativa social'
    ],
    benefits: [
      'Estabilidad laboral',
      'Beneficios del estado',
      'Capacitación continua',
      'Seguro de salud',
      'Vacaciones según ley'
    ]
  }
];

export function getJobById(id: string): Job | undefined {
  return allJobs.find(job => job.id === id);
}
