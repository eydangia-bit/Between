import Header from "@/components/Header";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";

export default function Privacy() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border-b">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Política de Privacidad
            </h1>
            <p className="text-lg text-muted-foreground">
              Última actualización: Noviembre 2025
            </p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <Card>
            <CardHeader>
              <p className="text-muted-foreground">
                En Between, nos tomamos muy en serio la privacidad de nuestros usuarios. Esta política 
                explica cómo recopilamos, usamos y protegemos tu información personal.
              </p>
            </CardHeader>
            <CardContent className="space-y-6">
              <section>
                <h2 className="text-2xl font-bold mb-3">1. Información que Recopilamos</h2>
                <div className="space-y-3 text-muted-foreground">
                  <h3 className="text-lg font-semibold text-foreground">1.1 Información Personal</h3>
                  <p>
                    Recopilamos información que proporcionas directamente, incluyendo:
                  </p>
                  <ul className="list-disc list-inside space-y-1 ml-4">
                    <li>Nombre completo y datos de contacto</li>
                    <li>Dirección de correo electrónico</li>
                    <li>Número de teléfono</li>
                    <li>Currículum vitae y experiencia laboral</li>
                    <li>Información de educación y certificaciones</li>
                    <li>Fotografía de perfil (opcional)</li>
                  </ul>

                  <h3 className="text-lg font-semibold text-foreground mt-4">1.2 Información de Uso</h3>
                  <p>
                    Recopilamos automáticamente información sobre cómo utilizas Between:
                  </p>
                  <ul className="list-disc list-inside space-y-1 ml-4">
                    <li>Páginas visitadas y tiempo de navegación</li>
                    <li>Empleos y cursos consultados</li>
                    <li>Interacciones con la plataforma</li>
                    <li>Dispositivo y navegador utilizado</li>
                    <li>Dirección IP y ubicación aproximada</li>
                  </ul>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-3">2. Cómo Usamos tu Información</h2>
                <div className="space-y-2 text-muted-foreground">
                  <p>Utilizamos la información recopilada para:</p>
                  <ul className="list-disc list-inside space-y-1 ml-4">
                    <li>Proporcionar, mantener y mejorar nuestros servicios</li>
                    <li>Conectarte con oportunidades laborales relevantes</li>
                    <li>Personalizar tu experiencia en la plataforma</li>
                    <li>Enviar notificaciones sobre empleos y actualizaciones</li>
                    <li>Procesar tus postulaciones a empleos</li>
                    <li>Prevenir fraudes y abusos</li>
                    <li>Cumplir con obligaciones legales</li>
                  </ul>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-3">3. Compartir Información</h2>
                <div className="space-y-3 text-muted-foreground">
                  <h3 className="text-lg font-semibold text-foreground">3.1 Con Empleadores</h3>
                  <p>
                    Compartimos tu perfil y CV con empleadores cuando postulas a una oferta laboral 
                    o cuando tu perfil coincide con sus búsquedas (solo si has autorizado esta función).
                  </p>

                  <h3 className="text-lg font-semibold text-foreground mt-4">3.2 Con Terceros</h3>
                  <p>
                    No vendemos tu información personal. Solo compartimos datos con:
                  </p>
                  <ul className="list-disc list-inside space-y-1 ml-4">
                    <li>Proveedores de servicios que nos ayudan a operar la plataforma</li>
                    <li>Autoridades cuando sea requerido por ley</li>
                    <li>Socios con tu consentimiento explícito</li>
                  </ul>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-3">4. Seguridad de Datos</h2>
                <div className="space-y-2 text-muted-foreground">
                  <p>
                    Implementamos medidas de seguridad técnicas y organizativas para proteger tu información:
                  </p>
                  <ul className="list-disc list-inside space-y-1 ml-4">
                    <li>Encriptación SSL/TLS para transmisión de datos</li>
                    <li>Almacenamiento seguro en servidores protegidos</li>
                    <li>Acceso restringido solo a personal autorizado</li>
                    <li>Auditorías de seguridad regulares</li>
                    <li>Protocolos de respuesta ante incidentes</li>
                  </ul>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-3">5. Tus Derechos</h2>
                <div className="space-y-2 text-muted-foreground">
                  <p>Tienes derecho a:</p>
                  <ul className="list-disc list-inside space-y-1 ml-4">
                    <li>Acceder a tu información personal</li>
                    <li>Rectificar datos incorrectos o incompletos</li>
                    <li>Solicitar la eliminación de tu cuenta y datos</li>
                    <li>Oponerte al procesamiento de ciertos datos</li>
                    <li>Exportar tu información en formato portable</li>
                    <li>Retirar tu consentimiento en cualquier momento</li>
                  </ul>
                  <p className="mt-4">
                    Para ejercer estos derechos, contáctanos en privacidad@between.pe
                  </p>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-3">6. Cookies y Tecnologías Similares</h2>
                <div className="space-y-2 text-muted-foreground">
                  <p>
                    Utilizamos cookies y tecnologías similares para mejorar tu experiencia. 
                    Puedes controlar las cookies desde la configuración de tu navegador.
                  </p>
                  <p>
                    Para más información, consulta nuestra Política de Cookies.
                  </p>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-3">7. Retención de Datos</h2>
                <div className="space-y-2 text-muted-foreground">
                  <p>
                    Conservamos tu información personal mientras tu cuenta esté activa o según sea 
                    necesario para proporcionarte servicios. Si eliminas tu cuenta, eliminaremos 
                    o anonimizaremos tu información dentro de 30 días, excepto cuando la ley 
                    requiera retenerla por más tiempo.
                  </p>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-3">8. Menores de Edad</h2>
                <div className="space-y-2 text-muted-foreground">
                  <p>
                    Between no está dirigido a menores de 18 años. No recopilamos intencionalmente 
                    información de menores. Si descubrimos que hemos recopilado datos de un menor, 
                    los eliminaremos inmediatamente.
                  </p>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-3">9. Cambios a esta Política</h2>
                <div className="space-y-2 text-muted-foreground">
                  <p>
                    Podemos actualizar esta política ocasionalmente. Te notificaremos sobre cambios 
                    significativos por correo electrónico o mediante un aviso en la plataforma.
                  </p>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-3">10. Contacto</h2>
                <div className="space-y-2 text-muted-foreground">
                  <p>
                    Si tienes preguntas sobre esta política de privacidad, contáctanos:
                  </p>
                  <div className="ml-4">
                    <p><strong>Email:</strong> privacidad@between.pe</p>
                    <p><strong>Dirección:</strong> Av. Javier Prado Este 2465, San Borja, Lima - Perú</p>
                    <p><strong>Teléfono:</strong> +51 1 234 5678</p>
                  </div>
                </div>
              </section>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
