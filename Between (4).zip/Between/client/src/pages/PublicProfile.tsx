import Header from "@/components/Header";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, Mail, Phone, Briefcase, GraduationCap, FileText, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { useState, useEffect } from "react";

interface Experience {
  id: string;
  type: 'work' | 'education';
  title: string;
  company: string;
  startDate: string;
  endDate: string;
  current: boolean;
  description?: string;
}

interface ProfileData {
  fullName: string;
  email: string;
  phone: string;
  location: string;
  bio: string;
  profileImage: string | null;
  experiences: Experience[];
}

const getProfileData = (): ProfileData => {
  const saved = localStorage.getItem('userProfile');
  if (saved) {
    return JSON.parse(saved);
  }
  return {
    fullName: 'Juan Pérez',
    location: 'Lima, Perú',
    email: 'juan.perez@email.com',
    phone: '+51 999 888 777',
    bio: 'Profesional con experiencia en desarrollo de software y gestión de proyectos.',
    profileImage: null,
    experiences: []
  };
};

export default function PublicProfile() {
  const [profileData, setProfileData] = useState<ProfileData>(getProfileData());

  useEffect(() => {
    setProfileData(getProfileData());
  }, []);

  const workExperiences = profileData.experiences.filter(exp => exp.type === 'work');
  const educationExperiences = profileData.experiences.filter(exp => exp.type === 'education');
  const skills = ['JavaScript', 'React', 'Node.js', 'TypeScript', 'SQL'];

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const formatDate = (date: string, current: boolean) => {
    if (current) return 'Presente';
    if (!date || date.trim() === '') return 'Presente';
    
    const [year, month] = date.split('-');
    if (!year || !month) return 'Presente';
    
    const months = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
    const monthIndex = parseInt(month) - 1;
    
    if (monthIndex < 0 || monthIndex >= 12) return 'Presente';
    
    return `${months[monthIndex]} ${year}`;
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Link href="/profile">
            <Button variant="ghost" className="mb-4" data-testid="button-back-to-profile">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Volver a mi perfil
            </Button>
          </Link>

          <Card className="mb-6">
            <CardContent className="pt-6">
              <div className="flex flex-col md:flex-row gap-6">
                <div className="flex flex-col items-center md:items-start">
                  <Avatar className="h-32 w-32 mb-4">
                    {profileData.profileImage ? (
                      <AvatarImage src={profileData.profileImage} alt={profileData.fullName} />
                    ) : (
                      <AvatarFallback className="text-3xl">{getInitials(profileData.fullName)}</AvatarFallback>
                    )}
                  </Avatar>
                </div>

                <div className="flex-1 text-center md:text-left">
                  <h1 className="text-3xl font-bold mb-2" data-testid="text-public-profile-name">
                    {profileData.fullName}
                  </h1>
                  
                  <div className="flex flex-col md:flex-row gap-4 mb-4 justify-center md:justify-start">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="h-4 w-4" />
                      <span>{profileData.location}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Mail className="h-4 w-4" />
                      <span>{profileData.email}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Phone className="h-4 w-4" />
                      <span>{profileData.phone}</span>
                    </div>
                  </div>

                  <p className="text-muted-foreground leading-relaxed mb-4">
                    {profileData.bio}
                  </p>

                  {skills.length > 0 && (
                    <div className="flex flex-wrap gap-2 justify-center md:justify-start">
                      {skills.map((skill, index) => (
                        <Badge key={index} variant="secondary">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {workExperiences.length > 0 && (
            <Card className="mb-6">
              <CardHeader>
                <h2 className="text-xl font-semibold flex items-center gap-2">
                  <Briefcase className="h-5 w-5" />
                  Experiencia Laboral
                </h2>
              </CardHeader>
              <CardContent className="space-y-4">
                {workExperiences.map((exp) => (
                  <div key={exp.id} className="border-l-2 border-primary pl-4">
                    <h3 className="font-semibold text-lg">{exp.title}</h3>
                    <p className="text-muted-foreground">{exp.company}</p>
                    <p className="text-sm text-muted-foreground mb-2">
                      {formatDate(exp.startDate, false)} - {exp.current ? 'Presente' : formatDate(exp.endDate, false)}
                    </p>
                    {exp.description && (
                      <p className="text-sm">{exp.description}</p>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {educationExperiences.length > 0 && (
            <Card>
              <CardHeader>
                <h2 className="text-xl font-semibold flex items-center gap-2">
                  <GraduationCap className="h-5 w-5" />
                  Formación Académica
                </h2>
              </CardHeader>
              <CardContent className="space-y-4">
                {educationExperiences.map((exp) => (
                  <div key={exp.id} className="border-l-2 border-primary pl-4">
                    <h3 className="font-semibold text-lg">{exp.title}</h3>
                    <p className="text-muted-foreground">{exp.company}</p>
                    <p className="text-sm text-muted-foreground">
                      {formatDate(exp.startDate, false)} - {exp.current ? 'Presente' : formatDate(exp.endDate, false)}
                    </p>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          <Card className="mt-6">
            <CardContent className="pt-6">
              <div className="text-center">
                <p className="text-sm text-muted-foreground mb-4">
                  ¿Interesado en contactar a {profileData.fullName.split(' ')[0]}?
                </p>
                <Button size="lg" data-testid="button-contact-candidate" className="w-full sm:w-auto">
                  <Mail className="h-4 w-4 mr-2" />
                  <span className="hidden sm:inline">Enviar Mensaje</span>
                  <span className="sm:hidden">Mensaje</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
