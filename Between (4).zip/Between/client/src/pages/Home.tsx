import Header from "@/components/Header";
import Hero from "@/components/Hero";
import JobCard from "@/components/JobCard";
import CourseCard from "@/components/CourseCard";
import Footer from "@/components/Footer";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight, Users, Briefcase, GraduationCap, TrendingUp } from "lucide-react";
import officeImage from "@assets/generated_images/Professional_office_workspace_Peru_5b617759.png";
import courseImage from "@assets/generated_images/Training_workshop_classroom_115620e8.png";
import interviewImage from "@assets/generated_images/Interview_preparation_professional_3a206720.png";
import { allJobs } from "@/data/jobs";

export default function Home() {
  const featuredJobs = allJobs.slice(0, 3);

  const featuredCourses = [
    {
      id: '1',
      title: 'Cómo Crear un Currículum Profesional',
      category: 'Preparación Laboral',
      duration: '2 horas',
      level: 'Principiante' as const,
      description: 'Aprende a diseñar un currículum que destaque tus habilidades y experiencia de manera efectiva.',
      imageUrl: courseImage
    },
    {
      id: '2',
      title: 'Técnicas de Entrevista Exitosa',
      category: 'Desarrollo Profesional',
      duration: '3 horas',
      level: 'Intermedio' as const,
      description: 'Domina las técnicas para impresionar en entrevistas laborales y conseguir el trabajo que deseas.',
      imageUrl: interviewImage
    },
    {
      id: '3',
      title: 'Habilidades Blandas para el Éxito',
      category: 'Desarrollo Personal',
      duration: '4 horas',
      level: 'Principiante' as const,
      description: 'Desarrolla comunicación efectiva, trabajo en equipo y liderazgo para destacar en tu carrera.',
      imageUrl: officeImage
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Hero />
      
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="hover-elevate">
              <CardContent className="pt-6 text-center">
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 mx-auto mb-4">
                  <Briefcase className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-2xl font-bold mb-1">5,000+</h3>
                <p className="text-sm text-muted-foreground">Empleos Activos</p>
              </CardContent>
            </Card>
            <Card className="hover-elevate">
              <CardContent className="pt-6 text-center">
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 mx-auto mb-4">
                  <Users className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-2xl font-bold mb-1">50,000+</h3>
                <p className="text-sm text-muted-foreground">Usuarios Registrados</p>
              </CardContent>
            </Card>
            <Card className="hover-elevate">
              <CardContent className="pt-6 text-center">
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 mx-auto mb-4">
                  <GraduationCap className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-2xl font-bold mb-1">200+</h3>
                <p className="text-sm text-muted-foreground">Cursos Disponibles</p>
              </CardContent>
            </Card>
            <Card className="hover-elevate">
              <CardContent className="pt-6 text-center">
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 mx-auto mb-4">
                  <TrendingUp className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-2xl font-bold mb-1">85%</h3>
                <p className="text-sm text-muted-foreground">Tasa de Éxito</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-8 gap-4 flex-wrap">
            <div>
              <h2 className="text-3xl font-bold mb-2">Empleos Destacados</h2>
              <p className="text-muted-foreground">Oportunidades que se ajustan a tu perfil</p>
            </div>
            <Link href="/jobs">
              <Button variant="outline" className="gap-2 w-full sm:w-auto" data-testid="button-view-all-jobs">
                <span className="hidden sm:inline">Ver Todos los Empleos</span>
                <span className="sm:hidden">Ver Empleos</span>
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredJobs.map(job => (
              <JobCard key={job.id} {...job} />
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-8 gap-4 flex-wrap">
            <div>
              <h2 className="text-3xl font-bold mb-2">Recursos Educativos</h2>
              <p className="text-muted-foreground">Desarrolla tus habilidades profesionales</p>
            </div>
            <Link href="/courses">
              <Button variant="outline" className="gap-2 w-full sm:w-auto" data-testid="button-view-all-courses">
                <span className="hidden sm:inline">Ver Todos los Recursos</span>
                <span className="sm:hidden">Ver Recursos</span>
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredCourses.map(course => (
              <CourseCard key={course.id} {...course} />
            ))}
          </div>
        </div>
      </section>

      <section className="py-16">
        <div className="container mx-auto px-4">
          <Card className="bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border-primary/20">
            <CardContent className="py-12 px-6 md:px-12">
              <div className="max-w-2xl">
                <h2 className="text-3xl font-bold mb-4">¿Listo para comenzar tu búsqueda?</h2>
                <p className="text-lg text-muted-foreground mb-6">
                  Únete a miles de profesionales que han encontrado su empleo ideal a través de Between. Regístrate gratis y accede a todas nuestras herramientas.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Link href="/register">
                    <Button size="lg" data-testid="button-register" className="w-full sm:w-auto">
                      <span className="hidden sm:inline">Crear Cuenta Gratis</span>
                      <span className="sm:hidden">Registrarse</span>
                    </Button>
                  </Link>
                  <Link href="/login">
                    <Button size="lg" variant="outline" data-testid="button-login-cta" className="w-full sm:w-auto">
                      Iniciar Sesión
                    </Button>
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      <Footer />
    </div>
  );
}
