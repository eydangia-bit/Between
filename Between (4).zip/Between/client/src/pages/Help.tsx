import Header from "@/components/Header";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Search, Briefcase, GraduationCap, Users, Shield } from "lucide-react";
import { useState } from "react";

export default function Help() {
  const [searchTerm, setSearchTerm] = useState("");

  const faqCategories = [
    {
      icon: Briefcase,
      title: "Búsqueda de Empleo",
      items: [
        {
          question: "¿Cómo busco empleos en Between?",
          answer: "Puedes buscar empleos utilizando la barra de búsqueda en la página de Empleos. Filtra por ubicación, tipo de empleo, salario y más para encontrar oportunidades que se ajusten a tu perfil."
        },
        {
          question: "¿Cómo postulo a un empleo?",
          answer: "Haz clic en la oferta de empleo que te interese y selecciona 'Postular Ahora'. Asegúrate de tener tu perfil completo y tu CV actualizado antes de postular."
        },
        {
          question: "¿Puedo guardar empleos para postular después?",
          answer: "Sí, puedes guardar empleos favoritos haciendo clic en el ícono de corazón. Accede a tus empleos guardados desde tu perfil."
        }
      ]
    },
    {
      icon: GraduationCap,
      title: "Cursos y Capacitación",
      items: [
        {
          question: "¿Los cursos son gratuitos?",
          answer: "Between ofrece tanto cursos gratuitos como premium. Los cursos gratuitos te permiten acceder a contenido básico, mientras que los premium incluyen certificaciones y material adicional."
        },
        {
          question: "¿Recibiré un certificado al completar un curso?",
          answer: "Sí, al completar un curso recibirás un certificado digital que puedes compartir en tu perfil y redes profesionales."
        },
        {
          question: "¿Puedo acceder a los cursos desde mi celular?",
          answer: "Sí, Between es completamente responsive y puedes acceder a todos los cursos desde cualquier dispositivo."
        }
      ]
    },
    {
      icon: Users,
      title: "Perfil y Cuenta",
      items: [
        {
          question: "¿Cómo creo mi perfil profesional?",
          answer: "Ve a la sección de Perfil y completa tu información personal, experiencia laboral, educación y habilidades. Un perfil completo aumenta tus posibilidades de ser contactado por empleadores."
        },
        {
          question: "¿Puedo modificar mi información después de registrarme?",
          answer: "Sí, puedes editar tu perfil en cualquier momento desde la sección de Perfil. Te recomendamos mantener tu información actualizada."
        },
        {
          question: "¿Cómo cambio mi contraseña?",
          answer: "Ve a Configuración en tu perfil y selecciona 'Cambiar Contraseña'. Necesitarás ingresar tu contraseña actual y la nueva contraseña dos veces."
        }
      ]
    },
    {
      icon: Shield,
      title: "Privacidad y Seguridad",
      items: [
        {
          question: "¿Mis datos están seguros?",
          answer: "Sí, utilizamos encriptación de nivel empresarial y seguimos las mejores prácticas de seguridad para proteger tu información personal."
        },
        {
          question: "¿Quién puede ver mi perfil?",
          answer: "Tu perfil es visible para empleadores verificados en la plataforma. Puedes ajustar la visibilidad de tu perfil en la configuración de privacidad."
        },
        {
          question: "¿Puedo eliminar mi cuenta?",
          answer: "Sí, puedes eliminar tu cuenta en cualquier momento desde Configuración > Eliminar Cuenta. Ten en cuenta que esta acción es permanente."
        }
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border-b">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Centro de Ayuda
            </h1>
            <p className="text-lg text-muted-foreground mb-8">
              Encuentra respuestas a las preguntas más frecuentes
            </p>
            <div className="relative max-w-xl mx-auto">
              <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Buscar en el centro de ayuda..."
                className="pl-10 h-12"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                data-testid="input-help-search"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto space-y-8">
          {faqCategories.map((category, idx) => (
            <Card key={idx}>
              <CardHeader>
                <h2 className="text-2xl font-bold flex items-center gap-3">
                  <category.icon className="h-6 w-6 text-primary" />
                  {category.title}
                </h2>
              </CardHeader>
              <CardContent>
                <Accordion type="single" collapsible className="w-full">
                  {category.items.map((item, itemIdx) => (
                    <AccordionItem key={itemIdx} value={`item-${idx}-${itemIdx}`}>
                      <AccordionTrigger className="text-left">
                        {item.question}
                      </AccordionTrigger>
                      <AccordionContent className="text-muted-foreground">
                        {item.answer}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
