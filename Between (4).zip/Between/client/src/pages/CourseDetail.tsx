import Header from "@/components/Header";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { Clock, BarChart, CheckCircle2, PlayCircle, FileText, Award } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useRoute } from "wouter";
import courseImage from "@assets/generated_images/Training_workshop_classroom_115620e8.png";
import interviewImage from "@assets/generated_images/Interview_preparation_professional_3a206720.png";
import officeImage from "@assets/generated_images/Professional_office_workspace_Peru_5b617759.png";

export default function CourseDetail() {
  const [, params] = useRoute("/courses/:id");
  const [progress, setProgress] = useState(0);
  const [completedLessons, setCompletedLessons] = useState<string[]>([]);
  const { toast } = useToast();

  //todo: remove mock functionality
  const courses: Record<string, any> = {
    '1': {
      id: '1',
      title: 'Cómo Crear un Currículum Profesional',
      category: 'Preparación Laboral',
      duration: '2 horas',
      level: 'Principiante',
      description: 'Aprende a diseñar un currículum que destaque tus habilidades y experiencia de manera efectiva. Este curso te guiará paso a paso en la creación de un CV profesional que capture la atención de los reclutadores.',
      imageUrl: courseImage,
      objectives: [
        'Estructurar correctamente un currículum profesional',
        'Destacar tus logros y habilidades de forma efectiva',
        'Adaptar tu CV a diferentes industrias y puestos',
        'Evitar errores comunes que rechazan las empresas',
        'Crear versiones digitales optimizadas para ATS'
      ],
      lessons: [
        { id: '1', title: 'Introducción: La importancia del CV', duration: '15 min', type: 'video' },
        { id: '2', title: 'Estructura básica del currículum', duration: '20 min', type: 'video' },
        { id: '3', title: 'Cómo redactar tu experiencia laboral', duration: '25 min', type: 'video' },
        { id: '4', title: 'Habilidades y competencias', duration: '20 min', type: 'video' },
        { id: '5', title: 'Plantilla descargable de CV', duration: '10 min', type: 'document' },
        { id: '6', title: 'Ejercicio práctico: Tu primer CV', duration: '30 min', type: 'quiz' }
      ]
    },
    '2': {
      id: '2',
      title: 'Técnicas de Entrevista Exitosa',
      category: 'Desarrollo Profesional',
      duration: '3 horas',
      level: 'Intermedio',
      description: 'Domina las técnicas para impresionar en entrevistas laborales y conseguir el trabajo que deseas. Aprende a responder preguntas difíciles con confianza.',
      imageUrl: interviewImage,
      objectives: [
        'Prepararte adecuadamente antes de una entrevista',
        'Responder preguntas comunes con seguridad',
        'Usar lenguaje corporal efectivo',
        'Negociar salario y beneficios',
        'Hacer seguimiento post-entrevista'
      ],
      lessons: [
        { id: '1', title: 'Preparación pre-entrevista', duration: '25 min', type: 'video' },
        { id: '2', title: 'Preguntas frecuentes y cómo responderlas', duration: '30 min', type: 'video' },
        { id: '3', title: 'Lenguaje corporal y comunicación no verbal', duration: '20 min', type: 'video' },
        { id: '4', title: 'Negociación salarial', duration: '25 min', type: 'video' },
        { id: '5', title: 'Simulación de entrevista', duration: '40 min', type: 'quiz' },
        { id: '6', title: 'Guía de seguimiento post-entrevista', duration: '10 min', type: 'document' }
      ]
    },
    '3': {
      id: '3',
      title: 'Habilidades Blandas para el Éxito',
      category: 'Desarrollo Personal',
      duration: '4 horas',
      level: 'Principiante',
      description: 'Desarrolla comunicación efectiva, trabajo en equipo y liderazgo para destacar en tu carrera profesional.',
      imageUrl: officeImage,
      objectives: [
        'Mejorar tus habilidades de comunicación',
        'Trabajar eficazmente en equipo',
        'Desarrollar inteligencia emocional',
        'Resolver conflictos de manera constructiva',
        'Liderar proyectos con confianza'
      ],
      lessons: [
        { id: '1', title: 'Comunicación efectiva en el trabajo', duration: '30 min', type: 'video' },
        { id: '2', title: 'Trabajo en equipo y colaboración', duration: '25 min', type: 'video' },
        { id: '3', title: 'Inteligencia emocional', duration: '35 min', type: 'video' },
        { id: '4', title: 'Resolución de conflictos', duration: '30 min', type: 'video' },
        { id: '5', title: 'Fundamentos de liderazgo', duration: '40 min', type: 'video' },
        { id: '6', title: 'Evaluación de habilidades blandas', duration: '20 min', type: 'quiz' }
      ]
    }
  };

  const course = courses[params?.id || '1'] || courses['1'];

  const handleStartLesson = (lessonId: string) => {
    if (!completedLessons.includes(lessonId)) {
      setCompletedLessons([...completedLessons, lessonId]);
      const newProgress = ((completedLessons.length + 1) / course.lessons.length) * 100;
      setProgress(newProgress);
      
      toast({
        title: "Lección Completada",
        description: "Has completado una lección exitosamente.",
      });
    }
  };

  const levelColors = {
    Principiante: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
    Intermedio: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400",
    Avanzado: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
  };

  const lessonIcons = {
    video: PlayCircle,
    document: FileText,
    quiz: Award,
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="relative h-80 overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${course.imageUrl})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-black/30" />
        
        <div className="relative z-10 h-full flex items-center">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl">
              <Badge className="mb-4" variant="secondary" data-testid="badge-category">
                {course.category}
              </Badge>
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-4" data-testid="text-course-title">
                {course.title}
              </h1>
              <div className="flex flex-wrap items-center gap-4 text-white/90">
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  <span data-testid="text-duration">{course.duration}</span>
                </div>
                <div className="flex items-center gap-2">
                  <BarChart className="h-5 w-5" />
                  <Badge className={levelColors[course.level as keyof typeof levelColors]} data-testid="badge-level">
                    {course.level}
                  </Badge>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <h2 className="text-xl font-semibold">Acerca del Curso</h2>
              </CardHeader>
              <CardContent className="space-y-6">
                <p className="text-muted-foreground leading-relaxed">
                  {course.description}
                </p>

                <div>
                  <h3 className="font-semibold mb-3">Objetivos de Aprendizaje</h3>
                  <ul className="space-y-2">
                    {course.objectives.map((objective: string, index: number) => (
                      <li key={index} className="flex gap-2">
                        <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                        <span className="text-muted-foreground">{objective}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <h2 className="text-xl font-semibold">Contenido del Curso</h2>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {course.lessons.map((lesson: any) => {
                    const Icon = lessonIcons[lesson.type as keyof typeof lessonIcons];
                    const isCompleted = completedLessons.includes(lesson.id);
                    
                    return (
                      <Card key={lesson.id} className={isCompleted ? 'border-primary/50' : ''} data-testid={`card-lesson-${lesson.id}`}>
                        <CardContent className="pt-6">
                          <div className="flex items-center justify-between gap-4 flex-wrap">
                            <div className="flex items-center gap-3 flex-1">
                              <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${isCompleted ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                                <Icon className="h-5 w-5" />
                              </div>
                              <div className="flex-1">
                                <h4 className="font-medium" data-testid={`text-lesson-title-${lesson.id}`}>
                                  {lesson.title}
                                </h4>
                                <p className="text-sm text-muted-foreground">
                                  {lesson.duration}
                                </p>
                              </div>
                            </div>
                            <Button
                              onClick={() => handleStartLesson(lesson.id)}
                              variant={isCompleted ? "outline" : "default"}
                              data-testid={`button-lesson-${lesson.id}`}
                            >
                              {isCompleted ? 'Completado' : 'Comenzar'}
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="sticky top-20">
              <CardHeader>
                <h2 className="text-xl font-semibold">Tu Progreso</h2>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Completado</span>
                    <span className="font-semibold" data-testid="text-progress-percentage">
                      {Math.round(progress)}%
                    </span>
                  </div>
                  <Progress value={progress} className="h-2" />
                  <p className="text-xs text-muted-foreground">
                    {completedLessons.length} de {course.lessons.length} lecciones completadas
                  </p>
                </div>

                <Separator />

                <div className="space-y-3">
                  <h3 className="font-semibold text-sm">Información del Curso</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Lecciones</span>
                      <span className="font-medium">{course.lessons.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Duración total</span>
                      <span className="font-medium">{course.duration}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Nivel</span>
                      <span className="font-medium">{course.level}</span>
                    </div>
                  </div>
                </div>

                <Separator />

                {progress === 100 && (
                  <Button className="w-full gap-2" data-testid="button-get-certificate">
                    <Award className="h-4 w-4" />
                    Obtener Certificado
                  </Button>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <h3 className="font-semibold">Cursos Relacionados</h3>
              </CardHeader>
              <CardContent className="space-y-3">
                {Object.values(courses)
                  .filter((c: any) => c.id !== course.id)
                  .slice(0, 2)
                  .map((relatedCourse: any) => (
                    <Card key={relatedCourse.id} className="hover-elevate cursor-pointer">
                      <CardContent className="pt-4">
                        <h4 className="font-medium text-sm mb-1">
                          {relatedCourse.title}
                        </h4>
                        <p className="text-xs text-muted-foreground">
                          {relatedCourse.duration} • {relatedCourse.level}
                        </p>
                      </CardContent>
                    </Card>
                  ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
