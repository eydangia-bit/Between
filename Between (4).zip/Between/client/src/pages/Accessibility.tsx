import Header from "@/components/Header";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Eye, Keyboard, Volume2, ZoomIn, Palette, MousePointer } from "lucide-react";

export default function Accessibility() {
  const features = [
    {
      icon: Eye,
      title: "Navegación Visual",
      description: "Alto contraste, textos escalables y diseño claro para facilitar la lectura."
    },
    {
      icon: Keyboard,
      title: "Navegación por Teclado",
      description: "Accede a todas las funciones usando solo el teclado con atajos intuitivos."
    },
    {
      icon: Volume2,
      title: "Lectores de Pantalla",
      description: "Compatible con JAWS, NVDA y otros lectores de pantalla populares."
    },
    {
      icon: ZoomIn,
      title: "Zoom y Ampliación",
      description: "Amplía el contenido hasta 200% sin pérdida de funcionalidad."
    },
    {
      icon: Palette,
      title: "Modo de Alto Contraste",
      description: "Opciones de color adaptadas para usuarios con daltonismo."
    },
    {
      icon: MousePointer,
      title: "Áreas Táctiles Grandes",
      description: "Botones y enlaces de tamaño adecuado para fácil interacción."
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border-b">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Accesibilidad
            </h1>
            <p className="text-lg text-muted-foreground">
              Nuestro compromiso con una plataforma inclusiva para todos
            </p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto space-y-8">
          <Card>
            <CardHeader>
              <h2 className="text-2xl font-bold">Nuestra Misión de Accesibilidad</h2>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                En Between, creemos que todas las personas merecen igualdad de acceso a oportunidades laborales 
                y recursos educativos. Por eso nos comprometemos a hacer que nuestra plataforma sea accesible 
                para todos los usuarios, independientemente de sus capacidades.
              </p>
              <p>
                Nos esforzamos por cumplir con las Pautas de Accesibilidad para el Contenido Web (WCAG) 2.1 
                nivel AA y seguimos mejorando continuamente nuestra plataforma para garantizar la mejor 
                experiencia posible para todos.
              </p>
            </CardContent>
          </Card>

          <div>
            <h2 className="text-2xl font-bold mb-6">Características de Accesibilidad</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {features.map((feature, idx) => (
                <Card key={idx} className="hover-elevate">
                  <CardContent className="pt-6">
                    <div className="flex gap-4">
                      <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 flex-shrink-0">
                        <feature.icon className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold mb-2">{feature.title}</h3>
                        <p className="text-sm text-muted-foreground">
                          {feature.description}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <Card>
            <CardHeader>
              <h2 className="text-2xl font-bold">Atajos de Teclado</h2>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center py-2 border-b">
                  <span className="font-medium">Ir al contenido principal</span>
                  <code className="px-3 py-1 bg-muted rounded text-sm">Alt + C</code>
                </div>
                <div className="flex justify-between items-center py-2 border-b">
                  <span className="font-medium">Abrir menú de navegación</span>
                  <code className="px-3 py-1 bg-muted rounded text-sm">Alt + M</code>
                </div>
                <div className="flex justify-between items-center py-2 border-b">
                  <span className="font-medium">Buscar en la plataforma</span>
                  <code className="px-3 py-1 bg-muted rounded text-sm">Ctrl + K</code>
                </div>
                <div className="flex justify-between items-center py-2 border-b">
                  <span className="font-medium">Ir al perfil</span>
                  <code className="px-3 py-1 bg-muted rounded text-sm">Alt + P</code>
                </div>
                <div className="flex justify-between items-center py-2">
                  <span className="font-medium">Ayuda y soporte</span>
                  <code className="px-3 py-1 bg-muted rounded text-sm">Alt + H</code>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <h2 className="text-2xl font-bold">Reportar Problemas de Accesibilidad</h2>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Si encuentras alguna barrera de accesibilidad en nuestra plataforma o tienes sugerencias 
                para mejorar, por favor contáctanos:
              </p>
              <div className="space-y-2">
                <p>
                  <strong>Email:</strong> accesibilidad@between.pe
                </p>
                <p>
                  <strong>Teléfono:</strong> +51 1 234 5678
                </p>
              </div>
              <p>
                Nos comprometemos a responder todas las consultas relacionadas con accesibilidad 
                dentro de 2 días hábiles.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <h2 className="text-2xl font-bold">Tecnologías de Asistencia</h2>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Between ha sido probado y es compatible con las siguientes tecnologías de asistencia:
              </p>
              <ul className="list-disc list-inside space-y-2">
                <li>JAWS (Job Access With Speech)</li>
                <li>NVDA (NonVisual Desktop Access)</li>
                <li>VoiceOver (macOS e iOS)</li>
                <li>TalkBack (Android)</li>
                <li>ZoomText</li>
                <li>Dragon NaturallySpeaking</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
