import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { UserPlus, LogIn } from "lucide-react";

const registerSchema = z.object({
  username: z.string().min(3, "El usuario debe tener al menos 3 caracteres"),
  email: z.string().email("Ingresa un correo electrónico válido"),
  password: z.string().min(6, "La contraseña debe tener al menos 6 caracteres"),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Las contraseñas no coinciden",
  path: ["confirmPassword"],
});

type RegisterForm = z.infer<typeof registerSchema>;

export default function Register() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const form = useForm<RegisterForm>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      email: "",
      password: "",
      confirmPassword: "",
    },
  });

  const onSubmit = async (data: RegisterForm) => {
    try {
      console.log("Register attempt:", data);
      
      // Guardar información del usuario en localStorage con su username como clave
      const userProfile = {
        fullName: data.username,
        email: data.email,
        phone: '',
        location: 'Lima, Perú',
        bio: '',
        health: 'good',
        disability: 'none',
        profileImage: null,
        experiences: []
      };
      
      // Guardar el perfil del usuario específico
      localStorage.setItem(`userProfile_${data.username}`, JSON.stringify(userProfile));
      
      // Establecer como usuario actual
      localStorage.setItem('currentUser', data.username);
      localStorage.setItem('userProfile', JSON.stringify(userProfile));
      
      toast({
        title: "Gracias por confiar en nosotros",
        description: "Tu cuenta ha sido creada exitosamente",
      });
      setTimeout(() => {
        setLocation("/");
      }, 500);
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo crear la cuenta. Por favor, intenta de nuevo.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-background flex items-center justify-center px-4 py-8">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2 mb-6" data-testid="link-logo">
            <div className="flex h-12 w-12 items-center justify-center rounded-md bg-primary text-primary-foreground">
              <span className="text-2xl font-bold">B</span>
            </div>
            <span className="text-2xl font-bold">Between</span>
          </Link>
          <h1 className="text-3xl font-bold mt-6 mb-2">Crear Cuenta</h1>
          <p className="text-muted-foreground">
            Únete a Between y encuentra tu próxima oportunidad
          </p>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-2 text-primary">
              <UserPlus className="h-5 w-5" />
              <h2 className="text-xl font-semibold">Completa tus datos</h2>
            </div>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Usuario</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Elige un nombre de usuario"
                          data-testid="input-username"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Correo Electrónico</FormLabel>
                      <FormControl>
                        <Input
                          type="email"
                          placeholder="tu@email.com"
                          data-testid="input-email"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Contraseña</FormLabel>
                      <FormControl>
                        <Input
                          type="password"
                          placeholder="Mínimo 6 caracteres"
                          data-testid="input-password"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="confirmPassword"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Confirmar Contraseña</FormLabel>
                      <FormControl>
                        <Input
                          type="password"
                          placeholder="Repite tu contraseña"
                          data-testid="input-confirm-password"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button
                  type="submit"
                  className="w-full"
                  disabled={form.formState.isSubmitting}
                  data-testid="button-submit-register"
                >
                  {form.formState.isSubmitting ? "Creando..." : (
                    <>
                      <span className="hidden sm:inline">Crear Cuenta</span>
                      <span className="sm:hidden">Crear Cuenta</span>
                    </>
                  )}
                </Button>
              </form>
            </Form>

            <div className="mt-6 pt-6 border-t text-center">
              <p className="text-sm text-muted-foreground mb-3">
                ¿Ya tienes una cuenta?
              </p>
              <Link href="/login">
                <Button variant="outline" className="w-full" data-testid="button-go-to-login">
                  <LogIn className="h-4 w-4 mr-2" />
                  Iniciar sesión
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        <div className="text-center mt-6">
          <Link href="/">
            <Button variant="ghost" size="sm" data-testid="button-back-home">
              Volver al inicio
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
