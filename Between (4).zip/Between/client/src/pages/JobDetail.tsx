import Header from "@/components/Header";
import FileUpload from "@/components/FileUpload";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { MapPin, DollarSign, Clock, Calendar, Building2, Users, CheckCircle2, ArrowLeft, Navigation, X } from "lucide-react";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { useParams, Link, useLocation } from "wouter";
import { getJobById } from "@/data/jobs";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { useMutation } from "@tanstack/react-query";

const jobIcon = L.divIcon({
  className: "custom-job-marker",
  html: `
    <div class="flex h-10 w-10 items-center justify-center rounded-full bg-blue-600 text-white shadow-lg border-2 border-white">
      <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"></path>
        <circle cx="12" cy="10" r="3"></circle>
      </svg>
    </div>
  `,
  iconSize: [40, 40],
  iconAnchor: [20, 40],
  popupAnchor: [0, -40],
});

const userIcon = L.divIcon({
  className: "custom-user-marker",
  html: `
    <div class="relative">
      <div class="flex h-12 w-12 items-center justify-center rounded-full bg-green-600 text-white shadow-xl border-4 border-white animate-pulse">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"></path>
          <circle cx="12" cy="7" r="4"></circle>
        </svg>
      </div>
      <div class="absolute inset-0 rounded-full bg-green-400 opacity-30 animate-ping"></div>
    </div>
  `,
  iconSize: [48, 48],
  iconAnchor: [24, 48],
  popupAnchor: [0, -48],
});

interface UserLocation {
  lat: number;
  lng: number;
}

function UserLocationMarker({ location }: { location: UserLocation }) {
  const map = useMap();

  useEffect(() => {
    map.flyTo([location.lat, location.lng], 13, {
      duration: 1.5,
    });
  }, [location, map]);

  return (
    <Marker position={[location.lat, location.lng]} icon={userIcon}>
      <Popup>
        <div className="text-center">
          <p className="font-semibold">Tú estás aquí</p>
        </div>
      </Popup>
    </Marker>
  );
}

export default function JobDetail() {
  const params = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [cvFile, setCvFile] = useState<File | null>(null);
  const [additionalDocsFile, setAdditionalDocsFile] = useState<File | null>(null);
  const [disabilityCertFile, setDisabilityCertFile] = useState<File | null>(null);
  const [userLocation, setUserLocation] = useState<UserLocation | null>(null);
  const [isLoadingLocation, setIsLoadingLocation] = useState(false);

  const job = getJobById(params.id || '');

  const requestUserLocation = () => {
    if (!navigator.geolocation) {
      toast({
        title: "Error",
        description: "Tu navegador no soporta geolocalización",
        variant: "destructive",
      });
      return;
    }

    setIsLoadingLocation(true);

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const location = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        };
        setUserLocation(location);
        setIsLoadingLocation(false);
        toast({
          title: "Ubicación activada",
          description: "Tu ubicación se ha marcado en el mapa",
        });
      },
      (error) => {
        setIsLoadingLocation(false);
        let errorMsg = "No se pudo obtener tu ubicación";
        
        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorMsg = "Permiso de ubicación denegado. Por favor, permite el acceso a tu ubicación.";
            break;
          case error.POSITION_UNAVAILABLE:
            errorMsg = "Información de ubicación no disponible";
            break;
          case error.TIMEOUT:
            errorMsg = "La solicitud de ubicación expiró";
            break;
        }
        
        toast({
          title: "Error de ubicación",
          description: errorMsg,
          variant: "destructive",
        });
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0,
      }
    );
  };

  const clearUserLocation = () => {
    setUserLocation(null);
    toast({
      title: "Ubicación desactivada",
      description: "Tu ubicación ha sido eliminada del mapa",
    });
  };

  const applicationMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await fetch("/api/job-application", {
        method: "POST",
        body: formData,
        credentials: "include",
      });

      if (!response.ok) {
        const contentType = response.headers.get("content-type");
        if (contentType && contentType.includes("application/json")) {
          const errorData = await response.json();
          throw new Error(errorData.details || errorData.error || response.statusText);
        }
        throw new Error(response.statusText);
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Postulación Enviada",
        description: "Tu postulación ha sido enviada exitosamente. Te contactaremos pronto.",
      });
      setCvFile(null);
      setAdditionalDocsFile(null);
      setDisabilityCertFile(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo enviar la postulación. Por favor intenta nuevamente.",
        variant: "destructive"
      });
    }
  });

  const handleApply = () => {
    if (!cvFile) {
      toast({
        title: "Error",
        description: "Debes adjuntar tu CV para postular.",
        variant: "destructive"
      });
      return;
    }

    if (!job) return;

    const formData = new FormData();
    formData.append("jobId", params.id || '');
    formData.append("jobTitle", job.title);
    formData.append("company", job.company);
    formData.append("cv", cvFile);
    
    if (additionalDocsFile) {
      formData.append("additionalDocs", additionalDocsFile);
    }
    
    if (disabilityCertFile) {
      formData.append("disabilityCert", disabilityCertFile);
    }

    applicationMutation.mutate(formData);
  };

  if (!job) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-3xl font-bold mb-4">Empleo no encontrado</h1>
          <p className="text-muted-foreground mb-6">
            El empleo que buscas no existe o ha sido removido.
          </p>
          <Link href="/jobs">
            <Button data-testid="button-back-to-jobs">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Volver a Empleos
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <Link href="/jobs">
          <Button variant="ghost" className="mb-4" data-testid="button-back">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Volver a empleos
          </Button>
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between gap-4 flex-wrap">
                  <div className="space-y-2 flex-1">
                    <h1 className="text-3xl font-bold" data-testid="text-job-title">
                      {job.title}
                    </h1>
                    <div className="flex items-center gap-2">
                      <Building2 className="h-5 w-5 text-muted-foreground" />
                      <span className="text-lg font-medium" data-testid="text-company">
                        {job.company}
                      </span>
                    </div>
                  </div>
                  <Badge data-testid="badge-job-type">{job.type}</Badge>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6">
                  <div className="flex items-center gap-2">
                    <MapPin className="h-5 w-5 text-muted-foreground" />
                    <span data-testid="text-location">{job.location}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-5 w-5 text-muted-foreground" />
                    <span className="font-medium" data-testid="text-salary">{job.salary}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-5 w-5 text-muted-foreground" />
                    <span data-testid="text-schedule">{job.schedule}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-5 w-5 text-muted-foreground" />
                    <span className="text-muted-foreground">Publicado {job.postedDate}</span>
                  </div>
                </div>
              </CardHeader>
            </Card>

            <Card>
              <CardHeader>
                <h2 className="text-xl font-semibold">Descripción del Puesto</h2>
              </CardHeader>
              <CardContent className="space-y-6">
                <p className="text-muted-foreground leading-relaxed">
                  {job.description}
                </p>

                {job.responsibilities && (
                  <div>
                    <h3 className="font-semibold mb-3">Responsabilidades</h3>
                    <ul className="space-y-2">
                      {job.responsibilities.map((item, index) => (
                        <li key={index} className="flex gap-2">
                          <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                          <span className="text-muted-foreground">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {job.responsibilities && job.requirements && <Separator />}

                {job.requirements && (
                  <div>
                    <h3 className="font-semibold mb-3">Requisitos</h3>
                    <ul className="space-y-2">
                      {job.requirements.map((item, index) => (
                        <li key={index} className="flex gap-2">
                          <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                          <span className="text-muted-foreground">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {job.requirements && job.benefits && <Separator />}

                {job.benefits && (
                  <div>
                    <h3 className="font-semibold mb-3">Beneficios</h3>
                    <ul className="space-y-2">
                      {job.benefits.map((item, index) => (
                        <li key={index} className="flex gap-2">
                          <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                          <span className="text-muted-foreground">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <h2 className="text-xl font-semibold flex items-center gap-2">
                  <MapPin className="h-5 w-5" />
                  Ubicación del Empleo
                </h2>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="relative h-[400px] rounded-lg overflow-hidden">
                  <MapContainer
                    center={[job.lat, job.lng]}
                    zoom={13}
                    style={{ height: "100%", width: "100%" }}
                    data-testid="map-job-location"
                  >
                    <TileLayer
                      attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                      url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    />
                    <Marker position={[job.lat, job.lng]} icon={jobIcon}>
                      <Popup>
                        <div className="min-w-[200px]">
                          <h3 className="font-semibold text-base">{job.title}</h3>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{job.company}</p>
                          <div className="flex items-center gap-1 mt-1 text-sm text-gray-500">
                            <MapPin className="h-3 w-3" />
                            <span>{job.location}</span>
                          </div>
                        </div>
                      </Popup>
                    </Marker>
                    {userLocation && <UserLocationMarker location={userLocation} />}
                  </MapContainer>
                </div>
                
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-start gap-2 text-sm text-muted-foreground">
                    <MapPin className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{job.location}</span>
                  </div>
                  
                  {!userLocation ? (
                    <Button
                      onClick={requestUserLocation}
                      disabled={isLoadingLocation}
                      size="sm"
                      variant="outline"
                      data-testid="button-enable-location-job-detail"
                    >
                      <Navigation className="h-4 w-4 mr-2" />
                      {isLoadingLocation ? "Obteniendo..." : "Activar mi ubicación"}
                    </Button>
                  ) : (
                    <Button
                      onClick={clearUserLocation}
                      variant="destructive"
                      size="sm"
                      data-testid="button-disable-location-job-detail"
                    >
                      <X className="h-4 w-4 mr-2" />
                      Desactivar
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="sticky top-20">
              <CardHeader>
                <h2 className="text-xl font-semibold">Postular a este Empleo</h2>
              </CardHeader>
              <CardContent className="space-y-4">
                <FileUpload 
                  label="Curriculum Vitae (CV)" 
                  accept=".pdf,.doc,.docx" 
                  onFileSelect={setCvFile}
                />
                <FileUpload 
                  label="Documentos Adicionales" 
                  optional 
                  accept=".pdf,.doc,.docx" 
                  onFileSelect={setAdditionalDocsFile}
                />
                <FileUpload 
                  label="Certificado de Discapacidad" 
                  optional 
                  accept=".pdf" 
                  onFileSelect={setDisabilityCertFile}
                />
                
                <Separator />
                
                <p className="text-xs text-muted-foreground">
                  Al postular, aceptas compartir tu información con {job.company} y confirmas que cumples con los requisitos del puesto.
                </p>
                
                <Button 
                  className="w-full" 
                  onClick={handleApply} 
                  data-testid="button-submit-application"
                  disabled={applicationMutation.isPending}
                >
                  {applicationMutation.isPending ? (
                    <span>Enviando...</span>
                  ) : (
                    <>
                      <span className="hidden sm:inline">Enviar Postulación</span>
                      <span className="sm:hidden">Postular</span>
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <h3 className="font-semibold flex items-center gap-2">
                  <Building2 className="h-5 w-5" />
                  Sobre la Empresa
                </h3>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  {job.company} es una empresa comprometida con la excelencia y el desarrollo profesional de sus colaboradores.
                </p>
                <div className="flex items-center gap-2 text-sm">
                  <Users className="h-4 w-4 text-muted-foreground" />
                  <span>Empresa verificada</span>
                </div>
                <Link href="/jobs">
                  <Button variant="outline" className="w-full" data-testid="button-view-company">
                    Ver Más Empleos
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
