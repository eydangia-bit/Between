import Header from "@/components/Header";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Cookie, Shield, Settings, BarChart } from "lucide-react";

export default function CookiesPolicy() {
  const cookieTypes = [
    {
      icon: Shield,
      title: "Cookies Esenciales",
      description: "Necesarias para el funcionamiento básico de la plataforma. No se pueden desactivar.",
      examples: ["Sesión de usuario", "Preferencias de idioma", "Seguridad"]
    },
    {
      icon: Settings,
      title: "Cookies de Funcionalidad",
      description: "Permiten recordar tus preferencias y personalizar tu experiencia.",
      examples: ["Tema (claro/oscuro)", "Configuraciones guardadas", "Preferencias de visualización"]
    },
    {
      icon: BarChart,
      title: "Cookies Analíticas",
      description: "Nos ayudan a entender cómo usas la plataforma para mejorarla.",
      examples: ["Páginas visitadas", "Tiempo de navegación", "Fuente de tráfico"]
    },
    {
      icon: Cookie,
      title: "Cookies de Marketing",
      description: "Se utilizan para mostrarte contenido y ofertas relevantes.",
      examples: ["Anuncios personalizados", "Ofertas de empleo sugeridas", "Cursos recomendados"]
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border-b">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Política de Cookies
            </h1>
            <p className="text-lg text-muted-foreground">
              Última actualización: Noviembre 2025
            </p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto space-y-8">
          <Card>
            <CardHeader>
              <h2 className="text-2xl font-bold mb-3">¿Qué son las cookies?</h2>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Las cookies son pequeños archivos de texto que se almacenan en tu dispositivo cuando 
                visitas un sitio web. Se utilizan ampliamente para hacer que los sitios web funcionen 
                de manera más eficiente, así como para proporcionar información a los propietarios del sitio.
              </p>
              <p>
                En Between, utilizamos cookies para mejorar tu experiencia, recordar tus preferencias 
                y entender cómo utilizas nuestra plataforma.
              </p>
            </CardContent>
          </Card>

          <div>
            <h2 className="text-2xl font-bold mb-6">Tipos de Cookies que Utilizamos</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {cookieTypes.map((type, idx) => (
                <Card key={idx} className="hover-elevate">
                  <CardContent className="pt-6 space-y-3">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 flex-shrink-0">
                        <type.icon className="h-5 w-5 text-primary" />
                      </div>
                      <h3 className="font-semibold text-lg">{type.title}</h3>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {type.description}
                    </p>
                    <div>
                      <p className="text-sm font-medium mb-2">Ejemplos:</p>
                      <ul className="text-sm text-muted-foreground space-y-1">
                        {type.examples.map((example, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <span className="text-primary mt-1">•</span>
                            <span>{example}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <Card>
            <CardHeader>
              <h2 className="text-2xl font-bold">Cookies de Terceros</h2>
            </CardHeader>
            <CardContent className="space-y-3 text-muted-foreground">
              <p>
                Además de nuestras propias cookies, también utilizamos cookies de terceros para:
              </p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li><strong>Google Analytics:</strong> Para analizar el uso de la plataforma</li>
                <li><strong>Redes Sociales:</strong> Para compartir contenido en redes sociales</li>
                <li><strong>Servicios de Publicidad:</strong> Para mostrar anuncios relevantes</li>
              </ul>
              <p>
                Estas cookies están sujetas a las políticas de privacidad de los respectivos terceros.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <h2 className="text-2xl font-bold">Duración de las Cookies</h2>
            </CardHeader>
            <CardContent className="space-y-3 text-muted-foreground">
              <div>
                <h3 className="font-semibold text-foreground mb-2">Cookies de Sesión</h3>
                <p>
                  Son temporales y se eliminan cuando cierras tu navegador. Se utilizan principalmente 
                  para mantener tu sesión activa mientras navegas.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-2">Cookies Persistentes</h3>
                <p>
                  Permanecen en tu dispositivo durante un período específico o hasta que las elimines 
                  manualmente. Se utilizan para recordar tus preferencias entre visitas.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <h2 className="text-2xl font-bold">Cómo Gestionar las Cookies</h2>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <p>
                Puedes controlar y gestionar las cookies de varias maneras:
              </p>
              
              <div>
                <h3 className="font-semibold text-foreground mb-2">1. Configuración del Navegador</h3>
                <p>
                  La mayoría de los navegadores te permiten:
                </p>
                <ul className="list-disc list-inside space-y-1 ml-4 mt-2">
                  <li>Ver qué cookies están instaladas</li>
                  <li>Bloquear todas o algunas cookies</li>
                  <li>Eliminar cookies existentes</li>
                  <li>Recibir alertas antes de que se instalen cookies</li>
                </ul>
              </div>

              <div>
                <h3 className="font-semibold text-foreground mb-2">2. Banner de Cookies de Between</h3>
                <p>
                  Al visitar nuestra plataforma por primera vez, verás un banner de cookies donde 
                  puedes aceptar o rechazar cookies no esenciales.
                </p>
              </div>

              <div>
                <h3 className="font-semibold text-foreground mb-2">3. Configuración de Privacidad</h3>
                <p>
                  En tu perfil, puedes acceder a la configuración de privacidad para ajustar tus 
                  preferencias de cookies en cualquier momento.
                </p>
              </div>

              <div className="p-4 bg-muted rounded-lg">
                <p className="font-medium text-foreground mb-2">⚠️ Importante:</p>
                <p>
                  Si bloqueas o eliminas las cookies esenciales, es posible que algunas funciones 
                  de Between no funcionen correctamente.
                </p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <h2 className="text-2xl font-bold">Información Recopilada por Cookies</h2>
            </CardHeader>
            <CardContent className="space-y-2 text-muted-foreground">
              <p>
                Las cookies pueden recopilar varios tipos de información, incluyendo:
              </p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Dirección IP y ubicación geográfica aproximada</li>
                <li>Tipo de navegador y dispositivo</li>
                <li>Páginas visitadas y tiempo de navegación</li>
                <li>Enlaces en los que haces clic</li>
                <li>Preferencias de idioma y configuración</li>
                <li>Historial de búsqueda dentro de la plataforma</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <h2 className="text-2xl font-bold">Actualizaciones de esta Política</h2>
            </CardHeader>
            <CardContent className="space-y-3 text-muted-foreground">
              <p>
                Podemos actualizar esta Política de Cookies ocasionalmente para reflejar cambios 
                en las tecnologías que utilizamos o por requisitos legales. Te notificaremos sobre 
                cambios significativos mediante un aviso en la plataforma.
              </p>
              <p>
                Te recomendamos revisar esta política periódicamente para mantenerte informado 
                sobre cómo utilizamos las cookies.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <h2 className="text-2xl font-bold">Contacto</h2>
            </CardHeader>
            <CardContent className="space-y-2 text-muted-foreground">
              <p>
                Si tienes preguntas sobre nuestra Política de Cookies, contáctanos:
              </p>
              <div className="ml-4 space-y-1">
                <p><strong>Email:</strong> privacidad@between.pe</p>
                <p><strong>Dirección:</strong> Av. Javier Prado Este 2465, San Borja, Lima - Perú</p>
                <p><strong>Teléfono:</strong> +51 1 234 5678</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
