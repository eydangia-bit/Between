import Header from "@/components/Header";
import { Card, CardContent, CardHeader } from "@/components/ui/card";

export default function Terms() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border-b">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Términos y Condiciones
            </h1>
            <p className="text-lg text-muted-foreground">
              Última actualización: Noviembre 2025
            </p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <Card>
            <CardHeader>
              <p className="text-muted-foreground">
                Por favor, lee estos términos y condiciones cuidadosamente antes de usar Between. 
                Al acceder y utilizar nuestra plataforma, aceptas estar sujeto a estos términos.
              </p>
            </CardHeader>
            <CardContent className="space-y-6">
              <section>
                <h2 className="text-2xl font-bold mb-3">1. Aceptación de los Términos</h2>
                <p className="text-muted-foreground">
                  Al acceder y utilizar Between, aceptas estar sujeto a estos términos y condiciones de uso, 
                  todas las leyes y regulaciones aplicables, y aceptas que eres responsable del cumplimiento 
                  de las leyes locales aplicables. Si no estás de acuerdo con alguno de estos términos, 
                  no debes usar nuestra plataforma.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-3">2. Uso de la Plataforma</h2>
                <div className="space-y-3 text-muted-foreground">
                  <h3 className="text-lg font-semibold text-foreground">2.1 Elegibilidad</h3>
                  <p>
                    Debes tener al menos 18 años para crear una cuenta en Between. Al registrarte, 
                    declaras que toda la información proporcionada es verdadera, precisa y actualizada.
                  </p>

                  <h3 className="text-lg font-semibold text-foreground mt-4">2.2 Cuenta de Usuario</h3>
                  <p>
                    Eres responsable de mantener la confidencialidad de tu cuenta y contraseña. 
                    Aceptas notificarnos inmediatamente sobre cualquier uso no autorizado de tu cuenta.
                  </p>

                  <h3 className="text-lg font-semibold text-foreground mt-4">2.3 Uso Aceptable</h3>
                  <p>
                    Te comprometes a utilizar la plataforma de manera responsable y respetuosa con otros usuarios. 
                    Está prohibido:
                  </p>
                  <ul className="list-disc list-inside space-y-1 ml-4">
                    <li>Publicar contenido ofensivo, difamatorio o ilegal</li>
                    <li>Suplantar la identidad de otra persona</li>
                    <li>Enviar spam o contenido no solicitado</li>
                    <li>Intentar acceder a cuentas de otros usuarios</li>
                    <li>Usar la plataforma para actividades fraudulentas</li>
                    <li>Interferir con el funcionamiento normal de Between</li>
                  </ul>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-3">3. Servicios Ofrecidos</h2>
                <div className="space-y-3 text-muted-foreground">
                  <h3 className="text-lg font-semibold text-foreground">3.1 Búsqueda de Empleo</h3>
                  <p>
                    Between facilita la conexión entre candidatos y empleadores. No garantizamos 
                    resultados específicos en las postulaciones ni somos responsables de las decisiones 
                    de contratación de los empleadores.
                  </p>

                  <h3 className="text-lg font-semibold text-foreground mt-4">3.2 Cursos y Capacitación</h3>
                  <p>
                    Ofrecemos acceso a recursos educativos y cursos. El contenido se proporciona 
                    "tal cual" y nos esforzamos por mantenerlo actualizado y preciso, pero no 
                    garantizamos su exactitud absoluta.
                  </p>

                  <h3 className="text-lg font-semibold text-foreground mt-4">3.3 Comunidad</h3>
                  <p>
                    Proporcionamos un espacio para que los usuarios compartan experiencias y conocimientos. 
                    No somos responsables del contenido generado por los usuarios, aunque nos reservamos 
                    el derecho de moderar y eliminar contenido inapropiado.
                  </p>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-3">4. Privacidad y Datos</h2>
                <p className="text-muted-foreground">
                  Nos comprometemos a proteger tu privacidad. La información personal que proporciones será 
                  utilizada únicamente para mejorar tu experiencia en la plataforma. No compartiremos tu 
                  información con terceros sin tu consentimiento explícito, excepto cuando sea requerido 
                  por ley. Para más detalles, consulta nuestra Política de Privacidad.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-3">5. Contenido del Usuario</h2>
                <div className="space-y-2 text-muted-foreground">
                  <p>
                    Eres responsable del contenido que publiques en la plataforma, incluyendo tu perfil, 
                    CV, comentarios y publicaciones. Al subir contenido:
                  </p>
                  <ul className="list-disc list-inside space-y-1 ml-4">
                    <li>Otorgas a Between una licencia para usar, mostrar y compartir ese contenido</li>
                    <li>Declaras que tienes derecho a compartir el contenido</li>
                    <li>Aceptas que podemos eliminar contenido que viole estos términos</li>
                    <li>Mantienes la propiedad de tu contenido original</li>
                  </ul>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-3">6. Propiedad Intelectual</h2>
                <p className="text-muted-foreground">
                  Todo el contenido de Between, incluyendo textos, gráficos, logotipos, íconos, imágenes, 
                  clips de audio y video, descargas digitales y software, es propiedad de Between o sus 
                  licenciantes y está protegido por las leyes de propiedad intelectual peruanas e 
                  internacionales. No puedes copiar, modificar o distribuir este contenido sin autorización.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-3">7. Limitación de Responsabilidad</h2>
                <div className="space-y-2 text-muted-foreground">
                  <p>
                    Between se proporciona "tal cual" y "según disponibilidad". No garantizamos que:
                  </p>
                  <ul className="list-disc list-inside space-y-1 ml-4">
                    <li>La plataforma estará libre de errores o interrupciones</li>
                    <li>Los defectos serán corregidos inmediatamente</li>
                    <li>El servicio será seguro o libre de virus</li>
                    <li>Encontrarás empleo a través de la plataforma</li>
                  </ul>
                  <p className="mt-3">
                    No seremos responsables por daños indirectos, incidentales, especiales o 
                    consecuentes derivados del uso o la imposibilidad de usar la plataforma.
                  </p>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-3">8. Indemnización</h2>
                <p className="text-muted-foreground">
                  Aceptas indemnizar y mantener indemne a Between, sus directores, empleados y agentes 
                  de cualquier reclamo o demanda, incluyendo honorarios razonables de abogados, 
                  realizados por terceros debido a o derivados de tu violación de estos términos o 
                  tu uso de la plataforma.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-3">9. Terminación</h2>
                <p className="text-muted-foreground">
                  Nos reservamos el derecho de suspender o terminar tu acceso a Between en cualquier 
                  momento, sin previo aviso, por cualquier motivo, incluyendo pero no limitado a la 
                  violación de estos términos. También puedes cancelar tu cuenta en cualquier momento 
                  desde la configuración de tu perfil.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-3">10. Modificaciones</h2>
                <p className="text-muted-foreground">
                  Nos reservamos el derecho de modificar estos términos en cualquier momento. 
                  Las modificaciones entrarán en vigor inmediatamente después de su publicación en la 
                  plataforma. Tu uso continuado de Between después de cualquier modificación constituye 
                  tu aceptación de los nuevos términos.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-3">11. Ley Aplicable</h2>
                <p className="text-muted-foreground">
                  Estos términos se regirán e interpretarán de acuerdo con las leyes del Perú. 
                  Cualquier disputa relacionada con estos términos estará sujeta a la jurisdicción 
                  exclusiva de los tribunales de Lima, Perú.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-3">12. Contacto</h2>
                <div className="space-y-2 text-muted-foreground">
                  <p>
                    Si tienes preguntas sobre estos términos y condiciones, puedes contactarnos:
                  </p>
                  <div className="ml-4">
                    <p><strong>Email:</strong> legal@between.pe</p>
                    <p><strong>Dirección:</strong> Av. Javier Prado Este 2465, San Borja, Lima - Perú</p>
                    <p><strong>Teléfono:</strong> +51 1 234 5678</p>
                  </div>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-bold mb-3">13. Divisibilidad</h2>
                <p className="text-muted-foreground">
                  Si alguna disposición de estos términos se considera inválida o inaplicable, 
                  esa disposición se limitará o eliminará en la medida mínima necesaria, y las 
                  disposiciones restantes permanecerán en pleno vigor y efecto.
                </p>
              </section>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
