import Header from "@/components/Header";
import CourseCard from "@/components/CourseCard";
import Footer from "@/components/Footer";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, BookOpen, GraduationCap, Briefcase } from "lucide-react";
import { useState, useMemo } from "react";
import courseImage from "@assets/generated_images/Training_workshop_classroom_115620e8.png";
import interviewImage from "@assets/generated_images/Interview_preparation_professional_3a206720.png";
import officeImage from "@assets/generated_images/Professional_office_workspace_Peru_5b617759.png";

export default function Courses() {
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [levelFilter, setLevelFilter] = useState('all');

  //todo: remove mock functionality
  const allCourses = [
    {
      id: '1',
      title: 'Cómo Crear un Currículum Profesional',
      category: 'Preparación Laboral',
      duration: '2 horas',
      level: 'Principiante' as const,
      description: 'Aprende a diseñar un currículum que destaque tus habilidades y experiencia de manera efectiva.',
      imageUrl: courseImage
    },
    {
      id: '2',
      title: 'Técnicas de Entrevista Exitosa',
      category: 'Desarrollo Profesional',
      duration: '3 horas',
      level: 'Intermedio' as const,
      description: 'Domina las técnicas para impresionar en entrevistas laborales y conseguir el trabajo que deseas.',
      imageUrl: interviewImage
    },
    {
      id: '3',
      title: 'Habilidades Blandas para el Éxito',
      category: 'Desarrollo Personal',
      duration: '4 horas',
      level: 'Principiante' as const,
      description: 'Desarrolla comunicación efectiva, trabajo en equipo y liderazgo para destacar en tu carrera.',
      imageUrl: officeImage
    },
    {
      id: '4',
      title: 'Marketing Digital Básico',
      category: 'Habilidades Técnicas',
      duration: '6 horas',
      level: 'Intermedio' as const,
      description: 'Aprende los fundamentos del marketing digital, redes sociales y publicidad online.',
      imageUrl: courseImage
    },
    {
      id: '5',
      title: 'Excel para Profesionales',
      category: 'Habilidades Técnicas',
      duration: '5 horas',
      level: 'Intermedio' as const,
      description: 'Domina Excel con fórmulas avanzadas, tablas dinámicas y automatización de procesos.',
      imageUrl: officeImage
    },
    {
      id: '6',
      title: 'Liderazgo y Gestión de Equipos',
      category: 'Desarrollo Profesional',
      duration: '8 horas',
      level: 'Avanzado' as const,
      description: 'Desarrolla habilidades de liderazgo efectivo para gestionar equipos de alto rendimiento.',
      imageUrl: interviewImage
    },
    {
      id: '7',
      title: 'Introducción a la Programación',
      category: 'Habilidades Técnicas',
      duration: '10 horas',
      level: 'Principiante' as const,
      description: 'Aprende los conceptos básicos de programación y lógica computacional desde cero.',
      imageUrl: courseImage
    },
    {
      id: '8',
      title: 'Gestión del Tiempo y Productividad',
      category: 'Desarrollo Personal',
      duration: '3 horas',
      level: 'Principiante' as const,
      description: 'Optimiza tu tiempo y aumenta tu productividad con técnicas probadas de gestión personal.',
      imageUrl: officeImage
    },
    {
      id: '9',
      title: 'Negociación Efectiva',
      category: 'Desarrollo Profesional',
      duration: '4 horas',
      level: 'Avanzado' as const,
      description: 'Aprende estrategias avanzadas de negociación para conseguir mejores acuerdos profesionales.',
      imageUrl: interviewImage
    }
  ];

  const filteredCourses = useMemo(() => {
    return allCourses.filter(course => {
      const matchesSearch = searchTerm === '' || 
        course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        course.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        course.category.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesCategory = categoryFilter === 'all' || 
        (categoryFilter === 'prep' && course.category === 'Preparación Laboral') ||
        (categoryFilter === 'prof' && course.category === 'Desarrollo Profesional') ||
        (categoryFilter === 'tech' && course.category === 'Habilidades Técnicas') ||
        (categoryFilter === 'soft' && course.category === 'Desarrollo Personal');
      
      const matchesLevel = levelFilter === 'all' || 
        (levelFilter === 'beginner' && course.level === 'Principiante') ||
        (levelFilter === 'intermediate' && course.level === 'Intermedio') ||
        (levelFilter === 'advanced' && course.level === 'Avanzado');
      
      return matchesSearch && matchesCategory && matchesLevel;
    });
  }, [searchTerm, categoryFilter, levelFilter]);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border-b">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Recursos Educativos
            </h1>
            <p className="text-lg text-muted-foreground mb-8">
              Desarrolla tus habilidades profesionales con nuestros cursos, talleres y guías especializadas
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Card className="hover-elevate">
                <CardContent className="pt-6 text-center">
                  <BookOpen className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <h3 className="font-semibold mb-1">Cursos</h3>
                  <p className="text-sm text-muted-foreground">Aprende a tu ritmo</p>
                </CardContent>
              </Card>
              <Card className="hover-elevate">
                <CardContent className="pt-6 text-center">
                  <GraduationCap className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <h3 className="font-semibold mb-1">Talleres</h3>
                  <p className="text-sm text-muted-foreground">Práctica guiada</p>
                </CardContent>
              </Card>
              <Card className="hover-elevate">
                <CardContent className="pt-6 text-center">
                  <Briefcase className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <h3 className="font-semibold mb-1">Guías</h3>
                  <p className="text-sm text-muted-foreground">Recursos descargables</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Buscar cursos, talleres o guías..."
                  className="pl-9"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  data-testid="input-course-search"
                />
              </div>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-full lg:w-48" data-testid="select-category">
                  <SelectValue placeholder="Categoría" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas las categorías</SelectItem>
                  <SelectItem value="prep">Preparación Laboral</SelectItem>
                  <SelectItem value="prof">Desarrollo Profesional</SelectItem>
                  <SelectItem value="tech">Habilidades Técnicas</SelectItem>
                  <SelectItem value="soft">Desarrollo Personal</SelectItem>
                </SelectContent>
              </Select>
              <Select value={levelFilter} onValueChange={setLevelFilter}>
                <SelectTrigger className="w-full lg:w-48" data-testid="select-level">
                  <SelectValue placeholder="Nivel" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los niveles</SelectItem>
                  <SelectItem value="beginner">Principiante</SelectItem>
                  <SelectItem value="intermediate">Intermedio</SelectItem>
                  <SelectItem value="advanced">Avanzado</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <div className="mb-6">
          <p className="text-sm text-muted-foreground" data-testid="text-results-count">
            {filteredCourses.length} {filteredCourses.length === 1 ? 'recurso disponible' : 'recursos disponibles'}
          </p>
        </div>

        {filteredCourses.length === 0 ? (
          <Card className="p-12">
            <div className="text-center">
              <Search className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-xl font-semibold mb-2">No se encontraron cursos</h3>
              <p className="text-muted-foreground mb-4">
                Intenta ajustar tus filtros o términos de búsqueda
              </p>
              <Button 
                variant="outline" 
                onClick={() => {
                  setSearchTerm('');
                  setCategoryFilter('all');
                  setLevelFilter('all');
                }}
                data-testid="button-clear-filters"
              >
                Limpiar Filtros
              </Button>
            </div>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCourses.map(course => (
              <CourseCard key={course.id} {...course} />
            ))}
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
}
