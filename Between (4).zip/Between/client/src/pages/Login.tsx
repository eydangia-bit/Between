import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { LogIn, UserPlus } from "lucide-react";

const loginSchema = z.object({
  username: z.string().min(3, "El usuario debe tener al menos 3 caracteres"),
  password: z.string().min(6, "La contraseña debe tener al menos 6 caracteres"),
});

type LoginForm = z.infer<typeof loginSchema>;

export default function Login() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const form = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  const onSubmit = async (data: LoginForm) => {
    try {
      console.log("Login attempt:", data);
      
      // Cargar el perfil del usuario desde localStorage
      const savedProfile = localStorage.getItem(`userProfile_${data.username}`);
      
      if (savedProfile) {
        // Si el usuario tiene un perfil guardado, cargarlo
        localStorage.setItem('userProfile', savedProfile);
      } else {
        // Si no tiene perfil, crear uno básico
        const basicProfile = {
          fullName: data.username,
          email: '',
          phone: '',
          location: 'Lima, Perú',
          bio: '',
          health: 'good',
          disability: 'none',
          profileImage: null,
          experiences: []
        };
        localStorage.setItem('userProfile', JSON.stringify(basicProfile));
      }
      
      // Guardar usuario actual en localStorage
      localStorage.setItem('currentUser', data.username);
      
      toast({
        title: "Hola de nuevo",
        description: "Nos alegra verte otra vez",
      });
      setTimeout(() => {
        setLocation("/");
      }, 500);
    } catch (error) {
      toast({
        title: "Error",
        description: "Credenciales inválidas. Por favor, intenta de nuevo.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-background flex items-center justify-center px-4 py-8">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2 mb-6" data-testid="link-logo">
            <div className="flex h-12 w-12 items-center justify-center rounded-md bg-primary text-primary-foreground">
              <span className="text-2xl font-bold">B</span>
            </div>
            <span className="text-2xl font-bold">Between</span>
          </Link>
          <h1 className="text-3xl font-bold mt-6 mb-2">Iniciar Sesión</h1>
          <p className="text-muted-foreground">
            Accede a tu cuenta para continuar
          </p>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-2 text-primary">
              <LogIn className="h-5 w-5" />
              <h2 className="text-xl font-semibold">Ingresa tus credenciales</h2>
            </div>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Usuario</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Tu nombre de usuario"
                          data-testid="input-username"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Contraseña</FormLabel>
                      <FormControl>
                        <Input
                          type="password"
                          placeholder="Tu contraseña"
                          data-testid="input-password"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex items-center justify-between text-sm">
                  <Link href="/forgot-password">
                    <a className="text-primary hover:underline" data-testid="link-forgot-password">
                      ¿Olvidaste tu contraseña?
                    </a>
                  </Link>
                </div>

                <Button
                  type="submit"
                  className="w-full"
                  disabled={form.formState.isSubmitting}
                  data-testid="button-submit-login"
                >
                  {form.formState.isSubmitting ? "Iniciando..." : "Iniciar Sesión"}
                </Button>
              </form>
            </Form>

            <div className="mt-6 pt-6 border-t text-center">
              <p className="text-sm text-muted-foreground mb-3">
                ¿No tienes una cuenta?
              </p>
              <Link href="/register">
                <Button variant="outline" className="w-full" data-testid="button-go-to-register">
                  <UserPlus className="h-4 w-4 mr-2" />
                  Crear cuenta nueva
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        <div className="text-center mt-6">
          <Link href="/">
            <Button variant="ghost" size="sm" data-testid="button-back-home">
              Volver al inicio
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
