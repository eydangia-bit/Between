import Header from "@/components/Header";
import FileUpload from "@/components/FileUpload";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { User, Briefcase, FileText, Settings, Save, Plus, Trash2, Edit, ExternalLink } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

interface Experience {
  id: string;
  type: 'work' | 'education';
  title: string;
  company: string;
  startDate: string;
  endDate: string;
  current: boolean;
  description?: string;
}

interface ProfileData {
  fullName: string;
  email: string;
  phone: string;
  location: string;
  bio: string;
  health: string;
  disability: string;
  profileImage: string | null;
  experiences: Experience[];
}

const getInitialProfileData = (): ProfileData => {
  const saved = localStorage.getItem('userProfile');
  if (saved) {
    return JSON.parse(saved);
  }
  
  // Si no hay perfil guardado, crear uno vacío
  const currentUser = localStorage.getItem('currentUser');
  return {
    fullName: currentUser || 'Usuario',
    email: '',
    phone: '',
    location: 'Lima, Perú',
    bio: '',
    health: 'good',
    disability: 'none',
    profileImage: null,
    experiences: []
  };
};

export default function Profile() {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isExperienceDialogOpen, setIsExperienceDialogOpen] = useState(false);
  const [editingExperience, setEditingExperience] = useState<Experience | null>(null);
  
  const initialData = getInitialProfileData();
  const [profileImage, setProfileImage] = useState<string | null>(initialData.profileImage);
  const [formData, setFormData] = useState({
    fullName: initialData.fullName,
    email: initialData.email,
    phone: initialData.phone,
    location: initialData.location,
    bio: initialData.bio,
    health: initialData.health,
    disability: initialData.disability,
  });
  const [experiences, setExperiences] = useState<Experience[]>(initialData.experiences);

  useEffect(() => {
    const profileData: ProfileData = {
      ...formData,
      profileImage,
      experiences
    };
    localStorage.setItem('userProfile', JSON.stringify(profileData));
    
    // También guardar en el perfil específico del usuario
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
      localStorage.setItem(`userProfile_${currentUser}`, JSON.stringify(profileData));
    }
  }, [formData, profileImage, experiences]);

  const [newExperience, setNewExperience] = useState<Partial<Experience>>({
    type: 'work',
    title: '',
    company: '',
    startDate: '',
    endDate: '',
    current: false,
    description: ''
  });

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "Error",
          description: "La imagen debe ser menor a 5MB.",
          variant: "destructive"
        });
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        setProfileImage(reader.result as string);
        toast({
          title: "Foto Actualizada",
          description: "Tu foto de perfil ha sido actualizada exitosamente.",
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    console.log('Profile saved:', formData);
    toast({
      title: "Perfil Actualizado",
      description: "Tus cambios han sido guardados exitosamente.",
    });
  };

  const handleAddExperience = () => {
    if (!newExperience.title || !newExperience.company || !newExperience.startDate) {
      toast({
        title: "Error",
        description: "Por favor completa todos los campos requeridos.",
        variant: "destructive"
      });
      return;
    }

    if (!newExperience.current && (!newExperience.endDate || newExperience.endDate.trim() === '')) {
      toast({
        title: "Error",
        description: "Por favor indica la fecha de fin o marca como 'Actual'.",
        variant: "destructive"
      });
      return;
    }

    if (editingExperience) {
      setExperiences(experiences.map(exp => 
        exp.id === editingExperience.id 
          ? { ...newExperience, id: exp.id } as Experience
          : exp
      ));
      toast({
        title: "Experiencia Actualizada",
        description: "La experiencia ha sido actualizada exitosamente.",
      });
    } else {
      const experience: Experience = {
        ...newExperience,
        id: Date.now().toString()
      } as Experience;
      setExperiences([...experiences, experience]);
      toast({
        title: "Experiencia Agregada",
        description: "La experiencia ha sido agregada exitosamente.",
      });
    }

    setNewExperience({
      type: 'work',
      title: '',
      company: '',
      startDate: '',
      endDate: '',
      current: false,
      description: ''
    });
    setEditingExperience(null);
    setIsExperienceDialogOpen(false);
  };

  const handleEditExperience = (exp: Experience) => {
    setEditingExperience(exp);
    setNewExperience(exp);
    setIsExperienceDialogOpen(true);
  };

  const handleDeleteExperience = (id: string) => {
    setExperiences(experiences.filter(exp => exp.id !== id));
    toast({
      title: "Experiencia Eliminada",
      description: "La experiencia ha sido eliminada exitosamente.",
    });
  };

  const handleDeleteAccount = () => {
    console.log('Account deleted');
    toast({
      title: "Cuenta Eliminada",
      description: "Tu cuenta ha sido eliminada permanentemente.",
      variant: "destructive"
    });
  };

  const workExperiences = experiences.filter(exp => exp.type === 'work');
  const educationExperiences = experiences.filter(exp => exp.type === 'education');

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-5xl mx-auto">
          <div className="mb-8">
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col sm:flex-row items-center gap-6">
                  <div className="relative">
                    <Avatar className="h-24 w-24">
                      {profileImage ? (
                        <AvatarImage src={profileImage} alt={formData.fullName} />
                      ) : (
                        <AvatarFallback className="text-2xl">{getInitials(formData.fullName)}</AvatarFallback>
                      )}
                    </Avatar>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                      data-testid="input-profile-image"
                    />
                  </div>
                  <div className="flex-1 text-center sm:text-left">
                    <h1 className="text-2xl font-bold mb-1" data-testid="text-user-name">
                      {formData.fullName}
                    </h1>
                    <p className="text-muted-foreground mb-3">{formData.location}</p>
                    <div className="flex flex-col sm:flex-row gap-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => fileInputRef.current?.click()}
                        data-testid="button-change-photo"
                      >
                        Cambiar Foto
                      </Button>
                      <Link href="/profile/public">
                        <Button variant="outline" size="sm" data-testid="button-view-public-profile">
                          <ExternalLink className="h-4 w-4 mr-2" />
                          Ver Perfil Público
                        </Button>
                      </Link>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="personal" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="personal" className="gap-2" data-testid="tab-personal">
                <User className="h-4 w-4" />
                Personal
              </TabsTrigger>
              <TabsTrigger value="experience" className="gap-2" data-testid="tab-experience">
                <Briefcase className="h-4 w-4" />
                Experiencia
              </TabsTrigger>
              <TabsTrigger value="documents" className="gap-2" data-testid="tab-documents">
                <FileText className="h-4 w-4" />
                Documentos
              </TabsTrigger>
              <TabsTrigger value="settings" className="gap-2" data-testid="tab-settings">
                <Settings className="h-4 w-4" />
                Configuración
              </TabsTrigger>
            </TabsList>

            <TabsContent value="personal">
              <Card>
                <CardHeader>
                  <h2 className="text-xl font-semibold">Información Personal</h2>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="fullName">Nombre Completo</Label>
                      <Input
                        id="fullName"
                        value={formData.fullName}
                        onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                        data-testid="input-full-name"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Correo Electrónico</Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        data-testid="input-email"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Teléfono</Label>
                      <Input
                        id="phone"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        data-testid="input-phone"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="location">Ubicación</Label>
                      <Input
                        id="location"
                        value={formData.location}
                        onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                        data-testid="input-location"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="bio">Biografía Profesional</Label>
                    <Textarea
                      id="bio"
                      rows={4}
                      value={formData.bio}
                      onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                      data-testid="textarea-bio"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="health">Estado de Salud</Label>
                      <Select 
                        value={formData.health}
                        onValueChange={(value) => setFormData({ ...formData, health: value })}
                      >
                        <SelectTrigger id="health" data-testid="select-health">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="good">Bueno</SelectItem>
                          <SelectItem value="fair">Regular</SelectItem>
                          <SelectItem value="poor">Requiere atención</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="disability">Condición de Discapacidad</Label>
                      <Select 
                        value={formData.disability}
                        onValueChange={(value) => setFormData({ ...formData, disability: value })}
                      >
                        <SelectTrigger id="disability" data-testid="select-disability">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">Ninguna</SelectItem>
                          <SelectItem value="physical">Física</SelectItem>
                          <SelectItem value="visual">Visual</SelectItem>
                          <SelectItem value="hearing">Auditiva</SelectItem>
                          <SelectItem value="other">Otra</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <Button onClick={handleSave} className="gap-2 w-full sm:w-auto" data-testid="button-save-personal">
                    <Save className="h-4 w-4" />
                    <span className="hidden sm:inline">Guardar Cambios</span>
                    <span className="sm:hidden">Guardar</span>
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="experience">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between gap-4 flex-wrap">
                    <h2 className="text-xl font-semibold">Experiencia y Formación</h2>
                    <Dialog open={isExperienceDialogOpen} onOpenChange={setIsExperienceDialogOpen}>
                      <DialogTrigger asChild>
                        <Button 
                          data-testid="button-add-experience"
                          onClick={() => {
                            setEditingExperience(null);
                            setNewExperience({
                              type: 'work',
                              title: '',
                              company: '',
                              startDate: '',
                              endDate: '',
                              current: false,
                              description: ''
                            });
                          }}
                        >
                          <Plus className="h-4 w-4 mr-2" />
                          Agregar Experiencia
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-2xl">
                        <DialogHeader>
                          <DialogTitle>
                            {editingExperience ? 'Editar Experiencia' : 'Agregar Nueva Experiencia'}
                          </DialogTitle>
                          <DialogDescription>
                            Completa la información sobre tu experiencia laboral o formación académica.
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div className="space-y-2">
                            <Label htmlFor="exp-type">Tipo</Label>
                            <Select 
                              value={newExperience.type}
                              onValueChange={(value: 'work' | 'education') => setNewExperience({ ...newExperience, type: value })}
                            >
                              <SelectTrigger id="exp-type" data-testid="select-experience-type">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="work">Experiencia Laboral</SelectItem>
                                <SelectItem value="education">Formación Académica</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="exp-title">
                              {newExperience.type === 'work' ? 'Cargo' : 'Título o Grado'}
                            </Label>
                            <Input
                              id="exp-title"
                              value={newExperience.title}
                              onChange={(e) => setNewExperience({ ...newExperience, title: e.target.value })}
                              placeholder={newExperience.type === 'work' ? 'Ej: Desarrollador Senior' : 'Ej: Licenciatura en Ingeniería'}
                              data-testid="input-experience-title"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="exp-company">
                              {newExperience.type === 'work' ? 'Empresa' : 'Institución'}
                            </Label>
                            <Input
                              id="exp-company"
                              value={newExperience.company}
                              onChange={(e) => setNewExperience({ ...newExperience, company: e.target.value })}
                              placeholder={newExperience.type === 'work' ? 'Ej: TechPeru SAC' : 'Ej: Universidad Nacional'}
                              data-testid="input-experience-company"
                            />
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <Label htmlFor="exp-start">Fecha de Inicio</Label>
                              <Input
                                id="exp-start"
                                type="month"
                                value={newExperience.startDate}
                                onChange={(e) => setNewExperience({ ...newExperience, startDate: e.target.value })}
                                data-testid="input-experience-start"
                              />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="exp-end">Fecha de Fin</Label>
                              <Input
                                id="exp-end"
                                type="month"
                                value={newExperience.endDate}
                                onChange={(e) => setNewExperience({ ...newExperience, endDate: e.target.value })}
                                disabled={newExperience.current}
                                data-testid="input-experience-end"
                              />
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              id="exp-current"
                              checked={newExperience.current}
                              onChange={(e) => setNewExperience({ 
                                ...newExperience, 
                                current: e.target.checked,
                                endDate: e.target.checked ? '' : newExperience.endDate
                              })}
                              className="h-4 w-4"
                              data-testid="checkbox-experience-current"
                            />
                            <Label htmlFor="exp-current" className="cursor-pointer">
                              {newExperience.type === 'work' ? 'Trabajo aquí actualmente' : 'Cursando actualmente'}
                            </Label>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="exp-description">Descripción (Opcional)</Label>
                            <Textarea
                              id="exp-description"
                              rows={3}
                              value={newExperience.description}
                              onChange={(e) => setNewExperience({ ...newExperience, description: e.target.value })}
                              placeholder="Describe tus responsabilidades y logros..."
                              data-testid="textarea-experience-description"
                            />
                          </div>
                        </div>
                        <DialogFooter>
                          <Button variant="outline" onClick={() => setIsExperienceDialogOpen(false)} data-testid="button-cancel-experience">
                            Cancelar
                          </Button>
                          <Button onClick={handleAddExperience} data-testid="button-save-experience">
                            {editingExperience ? 'Actualizar' : 'Agregar'}
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  {workExperiences.length > 0 && (
                    <div className="space-y-4">
                      <h3 className="font-semibold">Experiencia Laboral</h3>
                      {workExperiences.map((exp) => (
                        <Card key={exp.id}>
                          <CardContent className="pt-6">
                            <div className="flex items-start justify-between gap-4">
                              <div className="space-y-2 flex-1">
                                <h4 className="font-medium">{exp.title}</h4>
                                <p className="text-sm text-muted-foreground">{exp.company}</p>
                                <p className="text-sm text-muted-foreground">
                                  {exp.startDate} - {exp.current ? 'Presente' : exp.endDate}
                                </p>
                                {exp.description && (
                                  <p className="text-sm">{exp.description}</p>
                                )}
                              </div>
                              <div className="flex gap-2">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => handleEditExperience(exp)}
                                  data-testid={`button-edit-experience-${exp.id}`}
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => handleDeleteExperience(exp.id)}
                                  data-testid={`button-delete-experience-${exp.id}`}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}

                  {educationExperiences.length > 0 && (
                    <div className="space-y-4">
                      <h3 className="font-semibold">Formación Académica</h3>
                      {educationExperiences.map((exp) => (
                        <Card key={exp.id}>
                          <CardContent className="pt-6">
                            <div className="flex items-start justify-between gap-4">
                              <div className="space-y-2 flex-1">
                                <h4 className="font-medium">{exp.title}</h4>
                                <p className="text-sm text-muted-foreground">{exp.company}</p>
                                <p className="text-sm text-muted-foreground">
                                  {exp.startDate} - {exp.current ? 'Presente' : exp.endDate}
                                </p>
                                {exp.description && (
                                  <p className="text-sm">{exp.description}</p>
                                )}
                              </div>
                              <div className="flex gap-2">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => handleEditExperience(exp)}
                                  data-testid={`button-edit-experience-${exp.id}`}
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => handleDeleteExperience(exp.id)}
                                  data-testid={`button-delete-experience-${exp.id}`}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}

                  {experiences.length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">
                      <p>No has agregado ninguna experiencia aún.</p>
                      <p className="text-sm mt-2">Haz clic en "Agregar Experiencia" para comenzar.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="documents">
              <Card>
                <CardHeader>
                  <h2 className="text-xl font-semibold">Documentos</h2>
                </CardHeader>
                <CardContent className="space-y-6">
                  <FileUpload label="Curriculum Vitae (CV)" />
                  <FileUpload label="Certificados de Estudios" optional />
                  <FileUpload label="Certificado de Discapacidad" optional />
                  <FileUpload label="Otros Documentos" optional />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="settings">
              <Card>
                <CardHeader>
                  <h2 className="text-xl font-semibold">Configuración de Cuenta</h2>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <h3 className="font-semibold">Notificaciones</h3>
                    <div className="space-y-3">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" defaultChecked className="h-4 w-4" data-testid="checkbox-notifications-jobs" />
                        <span className="text-sm">Recibir notificaciones de nuevos empleos</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" defaultChecked className="h-4 w-4" data-testid="checkbox-notifications-courses" />
                        <span className="text-sm">Recibir recordatorios de cursos</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" className="h-4 w-4" data-testid="checkbox-notifications-newsletter" />
                        <span className="text-sm">Recibir newsletter semanal</span>
                      </label>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="font-semibold">Privacidad</h3>
                    <div className="space-y-3">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" defaultChecked className="h-4 w-4" data-testid="checkbox-privacy-visible" />
                        <span className="text-sm">Perfil visible para empleadores</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" className="h-4 w-4" data-testid="checkbox-privacy-contact" />
                        <span className="text-sm">Mostrar información de contacto</span>
                      </label>
                    </div>
                  </div>

                  <div className="pt-4 border-t">
                    <h3 className="font-semibold mb-3 text-destructive">Zona Peligrosa</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Una vez que elimines tu cuenta, no hay vuelta atrás. Por favor, está seguro.
                    </p>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="destructive" data-testid="button-delete-account">
                          <Trash2 className="h-4 w-4 mr-2" />
                          Eliminar Cuenta
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>¿Estás absolutamente seguro?</AlertDialogTitle>
                          <AlertDialogDescription>
                            Esta acción no se puede deshacer. Esto eliminará permanentemente tu cuenta
                            y todos los datos asociados de nuestros servidores.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel data-testid="button-cancel-delete">Cancelar</AlertDialogCancel>
                          <AlertDialogAction 
                            onClick={handleDeleteAccount}
                            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                            data-testid="button-confirm-delete"
                          >
                            Sí, eliminar mi cuenta
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
