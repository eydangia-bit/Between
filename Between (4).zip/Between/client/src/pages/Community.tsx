import Header from "@/components/Header";
import CommentSection from "@/components/CommentSection";
import Footer from "@/components/Footer";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Search, MessageSquare, TrendingUp, Users } from "lucide-react";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import type { Discussion, Comment } from "@shared/schema";

function formatRelativeTime(date: Date | string): string {
  const now = new Date();
  const then = new Date(date);
  const diffMs = now.getTime() - then.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 60) {
    return `hace ${diffMins} ${diffMins === 1 ? 'minuto' : 'minutos'}`;
  } else if (diffHours < 24) {
    return `hace ${diffHours} ${diffHours === 1 ? 'hora' : 'horas'}`;
  } else {
    return `hace ${diffDays} ${diffDays === 1 ? 'día' : 'días'}`;
  }
}

export default function Community() {
  const [searchTerm, setSearchTerm] = useState('');

  const { data: discussions = [], isLoading: isLoadingDiscussions } = useQuery<Discussion[]>({
    queryKey: ['/api/discussions'],
  });

  const { data: comments = [], isLoading: isLoadingComments } = useQuery<Comment[]>({
    queryKey: ['/api/comments'],
  });

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border-b">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Comunidad Between
            </h1>
            <p className="text-lg text-muted-foreground mb-8">
              Comparte experiencias, haz preguntas y conecta con otros profesionales
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Card className="hover-elevate">
                <CardContent className="pt-6 text-center">
                  <Users className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <h3 className="text-2xl font-bold mb-1">50K+</h3>
                  <p className="text-sm text-muted-foreground">Miembros</p>
                </CardContent>
              </Card>
              <Card className="hover-elevate">
                <CardContent className="pt-6 text-center">
                  <MessageSquare className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <h3 className="text-2xl font-bold mb-1">10K+</h3>
                  <p className="text-sm text-muted-foreground">Discusiones</p>
                </CardContent>
              </Card>
              <Card className="hover-elevate">
                <CardContent className="pt-6 text-center">
                  <TrendingUp className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <h3 className="text-2xl font-bold mb-1">500+</h3>
                  <p className="text-sm text-muted-foreground">Activos Hoy</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardContent className="pt-6">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Buscar en la comunidad..."
                    className="pl-9"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    data-testid="input-community-search"
                  />
                </div>
              </CardContent>
            </Card>

            <div className="space-y-4">
              {isLoadingDiscussions ? (
                <Card>
                  <CardContent className="pt-6">
                    <p className="text-center text-muted-foreground">Cargando discusiones...</p>
                  </CardContent>
                </Card>
              ) : discussions.length === 0 ? (
                <Card>
                  <CardContent className="pt-6">
                    <p className="text-center text-muted-foreground">No hay discusiones disponibles.</p>
                  </CardContent>
                </Card>
              ) : (
                discussions.map((discussion) => (
                  <Card key={discussion.id} className="hover-elevate active-elevate-2" data-testid={`card-discussion-${discussion.id}`}>
                    <CardContent className="pt-6">
                      <div className="flex gap-4">
                        <Avatar>
                          <AvatarFallback>{discussion.author.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1 space-y-2">
                          <div className="flex items-start justify-between gap-2 flex-wrap">
                            <h3 className="font-semibold text-lg hover:text-primary cursor-pointer" data-testid={`text-discussion-title-${discussion.id}`}>
                              {discussion.title}
                            </h3>
                            <Badge variant="secondary" data-testid={`badge-category-${discussion.id}`}>
                              {discussion.category}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground flex-wrap">
                            <span>{discussion.author}</span>
                            <span className="flex items-center gap-1">
                              <MessageSquare className="h-4 w-4" />
                              {discussion.replies} respuestas
                            </span>
                            <span>{discussion.views} vistas</span>
                            <span>{formatRelativeTime(discussion.timestamp)}</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>

            {isLoadingComments ? (
              <Card>
                <CardContent className="pt-6">
                  <p className="text-center text-muted-foreground">Cargando comentarios...</p>
                </CardContent>
              </Card>
            ) : (
              <CommentSection comments={comments.map(c => ({
                ...c,
                timestamp: formatRelativeTime(c.timestamp)
              }))} />
            )}
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <h3 className="font-semibold">Categorías Populares</h3>
              </CardHeader>
              <CardContent className="space-y-2">
                {['Consejos', 'Experiencias', 'Aprendizaje', 'Preguntas', 'Networking'].map((category) => (
                  <Button
                    key={category}
                    variant="ghost"
                    className="w-full justify-start"
                    data-testid={`button-category-${category.toLowerCase()}`}
                  >
                    {category}
                  </Button>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <h3 className="font-semibold">Nuevos en la Comunidad</h3>
              </CardHeader>
              <CardContent className="space-y-3">
                {['Pedro Silva', 'Laura Mendoza', 'Jorge Castro'].map((name, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <Avatar>
                      <AvatarFallback>{name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <p className="text-sm font-medium">{name}</p>
                      <p className="text-xs text-muted-foreground">Se unió hace {i + 1} días</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
