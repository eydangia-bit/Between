# Between - Employment Platform for Peru

## Overview

Between is a comprehensive employment platform designed specifically for the Peruvian job market. The platform connects job seekers with employment opportunities while providing educational resources to enhance employability. The application features job listings with geographic visualization, professional development courses, community engagement, and user profile management. The design emphasizes accessibility, trustworthiness, and inclusivity, particularly for people with disabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:**
- React with TypeScript for type-safe component development
- Wouter for lightweight client-side routing
- Vite as the build tool and development server
- TanStack Query (React Query) for server state management
- Tailwind CSS for utility-first styling with custom design system

**Design System:**
- Shadcn UI components (New York variant) with extensive Radix UI primitives
- Material Design foundation adapted for Peruvian cultural context
- Custom color system using HSL values with CSS variables for theming
- Typography: Inter (primary) and Poppins (secondary) from Google Fonts
- Responsive grid system with mobile-first breakpoints

**Component Architecture:**
- Reusable card components (JobCard, CourseCard) with consistent elevation states
- Interactive map interface for geographic job visualization
- Form components using React Hook Form with Zod validation
- File upload components with drag-and-drop functionality
- Comment/community interaction components

**State Management:**
- Query Client for API data fetching and caching
- Form state managed through React Hook Form
- Local component state for UI interactions
- Toast notifications for user feedback

### Backend Architecture

**Runtime & Framework:**
- Node.js with Express.js server
- TypeScript for type safety across server code
- ESM module system

**Server Structure:**
- Route registration pattern for API endpoints (prefix: `/api`)
- Storage abstraction layer with interface-based design
- Currently using in-memory storage (MemStorage) for development
- Extensible storage interface supports migration to database implementations

**Development Environment:**
- Vite middleware integration for HMR in development
- Custom logging for API requests with duration tracking
- Replit-specific plugins for development tooling

### Data Storage Solutions

**Database Configuration:**
- Drizzle ORM with PostgreSQL dialect
- Neon serverless PostgreSQL as the target database
- WebSocket connection support for Neon's serverless architecture
- Migration system configured (output: `./migrations`)

**Schema Design:**
- Users table with UUID primary keys (generated via `gen_random_uuid()`)
- Username/password authentication fields
- Zod schema validation integrated with Drizzle for type safety

**Current State:**
- Schema defined but storage layer uses in-memory implementation
- Database connection configured but not actively used
- Migration-ready structure for transitioning from mock data

### Authentication and Authorization

**Current Implementation:**
- Form-based login/register pages with client-side validation
- Zod schemas for credential validation (minimum 3-char username, 6-char password)
- Toast notifications for auth feedback
- No active session management or server-side authentication implemented

**Planned Architecture:**
- Session storage configured via connect-pg-simple
- User credentials stored in PostgreSQL users table
- Form validation prevents invalid submissions

### External Dependencies

**UI Component Libraries:**
- Radix UI primitives (accordion, dialog, dropdown, select, tabs, tooltip, etc.)
- CMDK for command palette functionality
- Vaul for drawer components
- Embla Carousel for carousel functionality
- React Day Picker for date selection

**Development Tools:**
- Drizzle Kit for database schema management and migrations
- ESBuild for production server bundling
- TSX for TypeScript execution in development
- Replit plugins (cartographer, dev banner, runtime error modal)

**Utilities:**
- Class Variance Authority (CVA) for component variant management
- clsx and tailwind-merge for className composition
- date-fns for date formatting
- nanoid for ID generation
- Zod for runtime type validation

**Asset Management:**
- Generated images stored in `attached_assets/generated_images/`
- Images used for hero sections, course cards, and office scenes
- Favicon support configured

**Styling Dependencies:**
- Tailwind CSS with PostCSS
- Autoprefixer for vendor prefix management
- Custom CSS variables for theming
- Google Fonts integration (Inter, Poppins)

**Email Service:**
- Resend for transactional email delivery
- Contact form emails sent to: eydangia@gmail.com
- Support form emails sent to: eydangia@gmail.com
- Job application emails sent to: eydangia@gmail.com with CV and document attachments
- API endpoints: `/api/contact`, `/api/support`, and `/api/job-application`
- Requires RESEND_API_KEY environment variable
- Uses `onboarding@resend.dev` as sender for development
- HTML-formatted emails with form submission details
- File upload support via Multer (10MB limit, PDF/DOC/DOCX formats)
- Job applications include CV (required) and optional additional documents and disability certificates