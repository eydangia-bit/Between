import { type User, type InsertUser, type Discussion, type InsertDiscussion, type Comment, type InsertComment, users, discussions, comments } from "@shared/schema";
import { randomUUID } from "crypto";
import { promises as fs } from "fs";
import { join } from "path";

const STORAGE_DIR = join(process.cwd(), ".storage");
const USERS_FILE = join(STORAGE_DIR, "users.json");
const DISCUSSIONS_FILE = join(STORAGE_DIR, "discussions.json");
const COMMENTS_FILE = join(STORAGE_DIR, "comments.json");

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getDiscussions(): Promise<Discussion[]>;
  getDiscussion(id: string): Promise<Discussion | undefined>;
  createDiscussion(discussion: InsertDiscussion): Promise<Discussion>;
  incrementDiscussionViews(id: string): Promise<void>;
  incrementDiscussionReplies(id: string): Promise<void>;
  
  getComments(discussionId?: string): Promise<Comment[]>;
  createComment(comment: InsertComment): Promise<Comment>;
  likeComment(id: string): Promise<void>;
}

export class FileStorage implements IStorage {
  private initialized = false;

  private async ensureStorageDir() {
    if (!this.initialized) {
      try {
        await fs.mkdir(STORAGE_DIR, { recursive: true });
        this.initialized = true;
      } catch (error) {
        console.error("Error creating storage directory:", error);
      }
    }
  }

  private async readJSON<T>(filepath: string, defaultValue: T): Promise<T> {
    await this.ensureStorageDir();
    try {
      const data = await fs.readFile(filepath, "utf-8");
      return JSON.parse(data, (key, value) => {
        if (key === 'timestamp' && typeof value === 'string') {
          return new Date(value);
        }
        return value;
      });
    } catch (error) {
      return defaultValue;
    }
  }

  private async writeJSON<T>(filepath: string, data: T): Promise<void> {
    await this.ensureStorageDir();
    await fs.writeFile(filepath, JSON.stringify(data, null, 2), "utf-8");
  }

  async getUser(id: string): Promise<User | undefined> {
    const users = await this.readJSON<User[]>(USERS_FILE, []);
    return users.find(u => u.id === id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const users = await this.readJSON<User[]>(USERS_FILE, []);
    return users.find(u => u.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const users = await this.readJSON<User[]>(USERS_FILE, []);
    const user: User = { 
      ...insertUser, 
      id: randomUUID(), 
      email: insertUser.email ?? null,
      createdAt: new Date() 
    };
    users.push(user);
    await this.writeJSON(USERS_FILE, users);
    return user;
  }

  async getDiscussions(): Promise<Discussion[]> {
    const discussions = await this.readJSON<Discussion[]>(DISCUSSIONS_FILE, []);
    return discussions.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async getDiscussion(id: string): Promise<Discussion | undefined> {
    const discussions = await this.readJSON<Discussion[]>(DISCUSSIONS_FILE, []);
    return discussions.find(d => d.id === id);
  }

  async createDiscussion(insertDiscussion: InsertDiscussion): Promise<Discussion> {
    const discussions = await this.readJSON<Discussion[]>(DISCUSSIONS_FILE, []);
    const discussion: Discussion = {
      ...insertDiscussion,
      id: randomUUID(),
      replies: 0,
      views: 0,
      timestamp: new Date()
    };
    discussions.push(discussion);
    await this.writeJSON(DISCUSSIONS_FILE, discussions);
    return discussion;
  }

  async incrementDiscussionViews(id: string): Promise<void> {
    const discussions = await this.readJSON<Discussion[]>(DISCUSSIONS_FILE, []);
    const discussion = discussions.find(d => d.id === id);
    if (discussion) {
      discussion.views++;
      await this.writeJSON(DISCUSSIONS_FILE, discussions);
    }
  }

  async incrementDiscussionReplies(id: string): Promise<void> {
    const discussions = await this.readJSON<Discussion[]>(DISCUSSIONS_FILE, []);
    const discussion = discussions.find(d => d.id === id);
    if (discussion) {
      discussion.replies++;
      await this.writeJSON(DISCUSSIONS_FILE, discussions);
    }
  }

  async getComments(discussionId?: string): Promise<Comment[]> {
    const comments = await this.readJSON<Comment[]>(COMMENTS_FILE, []);
    let filtered = comments;
    if (discussionId !== undefined) {
      filtered = comments.filter(c => c.discussionId === discussionId);
    }
    return filtered.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async createComment(insertComment: InsertComment): Promise<Comment> {
    const comments = await this.readJSON<Comment[]>(COMMENTS_FILE, []);
    const comment: Comment = {
      ...insertComment,
      discussionId: insertComment.discussionId ?? null,
      id: randomUUID(),
      likes: 0,
      timestamp: new Date()
    };
    comments.push(comment);
    await this.writeJSON(COMMENTS_FILE, comments);
    
    if (insertComment.discussionId) {
      await this.incrementDiscussionReplies(insertComment.discussionId);
    }
    
    return comment;
  }

  async likeComment(id: string): Promise<void> {
    const comments = await this.readJSON<Comment[]>(COMMENTS_FILE, []);
    const comment = comments.find(c => c.id === id);
    if (comment) {
      comment.likes++;
      await this.writeJSON(COMMENTS_FILE, comments);
    }
  }
}

export const storage = new FileStorage();
