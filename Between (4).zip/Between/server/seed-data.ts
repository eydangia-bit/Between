import { storage } from './storage';

export async function seedInitialData() {
  try {
    const existingDiscussions = await storage.getDiscussions();
    
    if (existingDiscussions.length === 0) {
      console.log('Seeding initial discussions...');
      await storage.createDiscussion({
        title: '¿Cómo negociar mejor salario en entrevistas?',
        author: 'María González',
        category: 'Consejos',
      });
      
      await storage.createDiscussion({
        title: 'Mi experiencia trabajando remoto desde Perú',
        author: 'Carlos Pérez',
        category: 'Experiencias',
      });
      
      await storage.createDiscussion({
        title: 'Recursos para aprender Python desde cero',
        author: 'Ana Torres',
        category: 'Aprendizaje',
      });
      
      await storage.createDiscussion({
        title: '¿Qué certificaciones son más valoradas?',
        author: 'Luis Ramírez',
        category: 'Preguntas',
      });
      console.log('Initial discussions seeded successfully');
    }

    const existingComments = await storage.getComments();
    
    if (existingComments.length === 0) {
      console.log('Seeding initial comments...');
      await storage.createComment({
        discussionId: null,
        author: 'María González',
        content: '¡Excelente plataforma! Encontré trabajo en solo 2 semanas gracias a los recursos y el mapa de empleos.',
      });
      
      await storage.createComment({
        discussionId: null,
        author: 'Carlos Pérez',
        content: 'Los cursos de preparación para entrevistas me ayudaron mucho. Muy recomendado para todos.',
      });
      
      await storage.createComment({
        discussionId: null,
        author: 'Ana Torres',
        content: 'Me encanta la comunidad. Aquí he encontrado mucho apoyo y consejos valiosos.',
      });
      console.log('Initial comments seeded successfully');
    }
  } catch (error) {
    console.error('Error seeding initial data:', error);
  }
}
