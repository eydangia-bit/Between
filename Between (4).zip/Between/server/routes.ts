import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertDiscussionSchema, insertCommentSchema, contactFormSchema, supportFormSchema, jobApplicationSchema } from "@shared/schema";
import { Resend } from "resend";
import { ZodError } from "zod";
import multer from "multer";

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedMimes = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ];
    if (allowedMimes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      const error = new multer.MulterError('LIMIT_UNEXPECTED_FILE', file.fieldname);
      error.message = 'Solo se permiten archivos PDF, DOC y DOCX';
      cb(error);
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/discussions", async (req, res) => {
    try {
      const discussions = await storage.getDiscussions();
      res.json(discussions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch discussions" });
    }
  });

  app.get("/api/discussions/:id", async (req, res) => {
    try {
      const discussion = await storage.getDiscussion(req.params.id);
      if (!discussion) {
        return res.status(404).json({ error: "Discussion not found" });
      }
      await storage.incrementDiscussionViews(req.params.id);
      res.json(discussion);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch discussion" });
    }
  });

  app.post("/api/discussions", async (req, res) => {
    try {
      const validatedData = insertDiscussionSchema.parse(req.body);
      const discussion = await storage.createDiscussion(validatedData);
      res.status(201).json(discussion);
    } catch (error) {
      res.status(400).json({ error: "Invalid discussion data" });
    }
  });

  app.get("/api/comments", async (req, res) => {
    try {
      const discussionId = req.query.discussionId as string | undefined;
      const comments = await storage.getComments(discussionId);
      res.json(comments);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch comments" });
    }
  });

  app.post("/api/comments", async (req, res) => {
    try {
      const validatedData = insertCommentSchema.parse(req.body);
      const comment = await storage.createComment(validatedData);
      res.status(201).json(comment);
    } catch (error) {
      res.status(400).json({ error: "Invalid comment data" });
    }
  });

  app.post("/api/comments/:id/like", async (req, res) => {
    try {
      await storage.likeComment(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to like comment" });
    }
  });

  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = contactFormSchema.parse(req.body);
      
      if (!process.env.RESEND_API_KEY) {
        return res.status(500).json({ error: "Email service not configured" });
      }

      const resend = new Resend(process.env.RESEND_API_KEY);
      
      const escapeHtml = (text: string) => {
        return text
          .replace(/&/g, "&amp;")
          .replace(/</g, "&lt;")
          .replace(/>/g, "&gt;")
          .replace(/"/g, "&quot;")
          .replace(/'/g, "&#039;")
          .replace(/\n/g, "<br>");
      };
      
      await resend.emails.send({
        from: "onboarding@resend.dev",
        to: "eydangia@gmail.com",
        subject: `Nuevo mensaje de contacto de ${validatedData.name}`,
        html: `
          <h2>Nuevo mensaje de contacto</h2>
          <p><strong>Nombre:</strong> ${escapeHtml(validatedData.name)}</p>
          <p><strong>Email:</strong> ${escapeHtml(validatedData.email)}</p>
          ${validatedData.phone ? `<p><strong>Teléfono:</strong> ${escapeHtml(validatedData.phone)}</p>` : ""}
          <p><strong>Mensaje:</strong></p>
          <p>${escapeHtml(validatedData.message)}</p>
        `,
      });

      res.json({ success: true });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          error: "Validation error",
          details: error.errors.map(e => e.message).join(", ")
        });
      }
      console.error("Failed to send contact email:", error);
      res.status(500).json({ error: "Failed to send email" });
    }
  });

  app.post("/api/support", async (req, res) => {
    try {
      const validatedData = supportFormSchema.parse(req.body);
      
      if (!process.env.RESEND_API_KEY) {
        return res.status(500).json({ error: "Email service not configured" });
      }

      const resend = new Resend(process.env.RESEND_API_KEY);
      
      const escapeHtml = (text: string) => {
        return text
          .replace(/&/g, "&amp;")
          .replace(/</g, "&lt;")
          .replace(/>/g, "&gt;")
          .replace(/"/g, "&quot;")
          .replace(/'/g, "&#039;")
          .replace(/\n/g, "<br>");
      };
      
      await resend.emails.send({
        from: "onboarding@resend.dev",
        to: "eydangia@gmail.com",
        subject: `Solicitud de soporte: ${validatedData.subject}`,
        html: `
          <h2>Nueva solicitud de soporte</h2>
          <p><strong>Nombre:</strong> ${escapeHtml(validatedData.name)}</p>
          <p><strong>Email:</strong> ${escapeHtml(validatedData.email)}</p>
          <p><strong>Asunto:</strong> ${escapeHtml(validatedData.subject)}</p>
          <p><strong>Mensaje:</strong></p>
          <p>${escapeHtml(validatedData.message)}</p>
        `,
      });

      res.json({ success: true });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          error: "Validation error",
          details: error.errors.map(e => e.message).join(", ")
        });
      }
      console.error("Failed to send support email:", error);
      res.status(500).json({ error: "Failed to send email" });
    }
  });

  app.post("/api/job-application", (req, res, next) => {
    upload.fields([
      { name: 'cv', maxCount: 1 },
      { name: 'additionalDocs', maxCount: 1 },
      { name: 'disabilityCert', maxCount: 1 }
    ])(req, res, (err) => {
      if (err instanceof multer.MulterError) {
        return res.status(400).json({
          error: "File upload error",
          details: err.message
        });
      }
      if (err) {
        return res.status(400).json({
          error: "File upload error",
          details: err.message || "Error al procesar archivos"
        });
      }
      next();
    });
  }, async (req, res) => {
    try {
      if (!process.env.RESEND_API_KEY) {
        return res.status(500).json({ error: "Email service not configured" });
      }

      const files = req.files as { [fieldname: string]: Express.Multer.File[] };
      
      // Validate form data
      const validatedData = jobApplicationSchema.parse({
        jobId: req.body.jobId,
        jobTitle: req.body.jobTitle,
        company: req.body.company,
        applicantName: req.body.applicantName,
        applicantEmail: req.body.applicantEmail,
        cvFileName: files.cv?.[0]?.originalname,
        additionalDocsFileName: files.additionalDocs?.[0]?.originalname,
        disabilityCertFileName: files.disabilityCert?.[0]?.originalname,
      });

      if (!files.cv || files.cv.length === 0) {
        return res.status(400).json({ 
          error: "Validation error",
          details: "El CV es requerido"
        });
      }

      const resend = new Resend(process.env.RESEND_API_KEY);

      // Prepare attachments for Resend
      const attachments: Array<{ filename: string; content: Buffer }> = [];
      
      // Add CV
      if (files.cv && files.cv[0]) {
        attachments.push({
          filename: files.cv[0].originalname,
          content: files.cv[0].buffer,
        });
      }

      // Add additional docs if present
      if (files.additionalDocs && files.additionalDocs[0]) {
        attachments.push({
          filename: files.additionalDocs[0].originalname,
          content: files.additionalDocs[0].buffer,
        });
      }

      // Add disability certificate if present
      if (files.disabilityCert && files.disabilityCert[0]) {
        attachments.push({
          filename: files.disabilityCert[0].originalname,
          content: files.disabilityCert[0].buffer,
        });
      }

      const escapeHtml = (text: string) => {
        return text
          .replace(/&/g, "&amp;")
          .replace(/</g, "&lt;")
          .replace(/>/g, "&gt;")
          .replace(/"/g, "&quot;")
          .replace(/'/g, "&#039;");
      };

      await resend.emails.send({
        from: "onboarding@resend.dev",
        to: "eydangia@gmail.com",
        subject: `Nueva postulación: ${validatedData.jobTitle} en ${validatedData.company}`,
        html: `
          <h2>Nueva Postulación Recibida</h2>
          <p><strong>Puesto:</strong> ${escapeHtml(validatedData.jobTitle)}</p>
          <p><strong>Empresa:</strong> ${escapeHtml(validatedData.company)}</p>
          <p><strong>Job ID:</strong> ${escapeHtml(validatedData.jobId)}</p>
          <br/>
          <p><strong>Archivos adjuntos:</strong></p>
          <ul>
            ${attachments.map(att => `<li>${escapeHtml(att.filename)}</li>`).join('')}
          </ul>
        `,
        attachments: attachments,
      });

      res.json({ success: true });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          error: "Validation error",
          details: error.errors.map(e => e.message).join(", ")
        });
      }
      console.error("Failed to send job application email:", error);
      res.status(500).json({ error: "Failed to send application" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
