import { db } from './db';
import { discussions, comments } from '@shared/schema';

async function seed() {
  console.log('Seeding database...');

  const seedDiscussions = [
    {
      title: '¿Cómo negociar mejor salario en entrevistas?',
      author: 'María González',
      category: 'Consejos',
    },
    {
      title: 'Mi experiencia trabajando remoto desde Perú',
      author: 'Carlos Pérez',
      category: 'Experiencias',
    },
    {
      title: 'Recursos para aprender Python desde cero',
      author: 'Ana Torres',
      category: 'Aprendizaje',
    },
    {
      title: '¿Qué certificaciones son más valoradas?',
      author: 'Luis Ramírez',
      category: 'Preguntas',
    }
  ];

  const seedComments = [
    {
      discussionId: null,
      author: 'María González',
      content: '¡Excelente plataforma! Encontré trabajo en solo 2 semanas gracias a los recursos y el mapa de empleos.',
    },
    {
      discussionId: null,
      author: 'Carlos Pérez',
      content: 'Los cursos de preparación para entrevistas me ayudaron mucho. Muy recomendado para todos.',
    },
    {
      discussionId: null,
      author: 'Ana Torres',
      content: 'Me encanta la comunidad. Aquí he encontrado mucho apoyo y consejos valiosos.',
    }
  ];

  try {
    console.log('Checking if tables exist...');
    const discussionCount = await db.select().from(discussions);
    
    if (discussionCount.length === 0) {
      console.log('Inserting seed discussions...');
      await db.insert(discussions).values(seedDiscussions);
      console.log('Inserted discussions');
    } else {
      console.log('Discussions already exist, skipping...');
    }

    const commentCount = await db.select().from(comments);
    if (commentCount.length === 0) {
      console.log('Inserting seed comments...');
      await db.insert(comments).values(seedComments);
      console.log('Inserted comments');
    } else {
      console.log('Comments already exist, skipping...');
    }

    console.log('Seeding completed successfully!');
  } catch (error) {
    console.error('Error seeding database:', error);
    throw error;
  }
}

seed()
  .then(() => {
    console.log('Done!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('Seed failed:', error);
    process.exit(1);
  });
